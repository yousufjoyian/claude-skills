"""
Build Initial Processed Files Registry

Scans the 4 Drive DASHCAM folders (Movie_F, Movie_R, Park_F, Park_R)
and creates a registry of all already-processed files.

This registry will be used by sync operations to skip re-copying
files that have already been processed.
"""

import json
from pathlib import Path
from datetime import datetime
import re
from typing import Dict, List

# File naming pattern: YYYYMMDDHHMMSS_XXXXXXA/B.MP4
VIDEO_PATTERN = re.compile(r'^(\d{14})_(\d{6})([AB])\.MP4$', re.IGNORECASE)

# Folders containing already-processed files
PROCESSED_FOLDERS = [
    r"G:\My Drive\PROJECTS\INVESTIGATION\DASHCAM\Movie_F",
    r"G:\My Drive\PROJECTS\INVESTIGATION\DASHCAM\Movie_R",
    r"G:\My Drive\PROJECTS\INVESTIGATION\DASHCAM\Park_F",
    r"G:\My Drive\PROJECTS\INVESTIGATION\DASHCAM\Park_R"
]


def get_camera_type(filename: str) -> str:
    """
    Determine camera type from filename.

    Pattern: YYYYMMDDHHMMSS_XXXXXXA/B.MP4
    - File ID < 53000 = Movie mode (driving)
    - File ID >= 53000 = Park mode (parked)
    - Suffix A = Front camera
    - Suffix B = Rear camera
    """
    match = VIDEO_PATTERN.match(filename)
    if not match:
        return "Unknown"

    file_id = int(match.group(2))
    suffix = match.group(3)

    if file_id < 53000:
        return "Movie_F" if suffix == 'A' else "Movie_R"
    else:
        return "Park_F" if suffix == 'A' else "Park_R"


def scan_folder(folder_path: Path) -> List[Dict]:
    """Scan a folder and return list of video file metadata."""
    files = []

    if not folder_path.exists():
        print(f"WARNING: Folder not found: {folder_path}")
        return files

    for video_file in folder_path.glob("*.MP4"):
        try:
            stat = video_file.stat()
            camera_type = get_camera_type(video_file.name)

            files.append({
                'filename': video_file.name,
                'camera_type': camera_type,
                'file_size_bytes': stat.st_size,
                'location': str(folder_path),
                'first_seen': datetime.now().isoformat(),
                'processed_date': datetime.fromtimestamp(stat.st_mtime).date().isoformat()
            })
        except Exception as e:
            print(f"ERROR reading {video_file.name}: {e}")

    return files


def build_registry() -> Dict:
    """Build complete registry from all processed folders."""
    print("Building initial processed files registry...\n")

    registry = {
        'metadata': {
            'created': datetime.now().isoformat(),
            'last_updated': datetime.now().isoformat(),
            'source_folders': PROCESSED_FOLDERS,
            'version': '1.0'
        },
        'processed_files': {},
        'statistics': {
            'total_count': 0,
            'by_camera': {
                'Movie_F': 0,
                'Movie_R': 0,
                'Park_F': 0,
                'Park_R': 0,
                'Unknown': 0
            },
            'total_size_gb': 0.0
        }
    }

    total_size = 0

    for folder_str in PROCESSED_FOLDERS:
        folder_path = Path(folder_str)
        camera_type = folder_path.name  # Movie_F, Movie_R, etc.

        print(f"Scanning: {camera_type}...")
        files = scan_folder(folder_path)

        for file_info in files:
            filename = file_info['filename']

            # Store in registry
            registry['processed_files'][filename] = file_info

            # Update statistics
            detected_camera = file_info['camera_type']
            registry['statistics']['by_camera'][detected_camera] += 1
            total_size += file_info['file_size_bytes']

        print(f"  Found: {len(files)} files\n")

    # Finalize statistics
    registry['statistics']['total_count'] = len(registry['processed_files'])
    registry['statistics']['total_size_gb'] = round(total_size / (1024**3), 2)

    return registry


def save_registry(registry: Dict, output_path: Path):
    """Save registry to JSON file with pretty formatting."""
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w') as f:
        json.dump(registry, f, indent=2, sort_keys=False)

    print(f"\nRegistry saved to: {output_path}")
    print(f"Registry size: {output_path.stat().st_size / 1024:.1f} KB")


def print_summary(registry: Dict):
    """Print summary statistics."""
    print("\n" + "="*60)
    print("REGISTRY SUMMARY")
    print("="*60)
    print(f"Total processed files: {registry['statistics']['total_count']}")
    print(f"Total size: {registry['statistics']['total_size_gb']} GB")
    print(f"\nBreakdown by camera type:")
    for camera, count in registry['statistics']['by_camera'].items():
        if count > 0:
            print(f"  {camera}: {count} files")
    print("="*60)


if __name__ == "__main__":
    # Build registry
    registry = build_registry()

    # Save to skill's data folder
    output_path = Path(__file__).parent.parent / "data" / "processed_registry.json"
    save_registry(registry, output_path)

    # Print summary
    print_summary(registry)

    print("\nRegistry ready for sync operations!")
