"""
Dashcam Sync - Smart File Transfer

Syncs new dashcam files from external drive to Desktop CARDV folder,
automatically skipping files that have already been processed.

Usage:
    python sync_dashcam.py --source E:\ --destination C:\\Users\\yousu\\Desktop\\CARDV
    python sync_dashcam.py --source F:\\DCIM --dry-run
"""

import json
import shutil
from pathlib import Path
from datetime import datetime
import re
import argparse
from typing import Dict, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# File naming pattern: YYYYMMDDHHMMSS_XXXXXXA/B.MP4
VIDEO_PATTERN = re.compile(r'^(\d{14})_(\d{6})([AB])\.MP4$', re.IGNORECASE)

# Default paths
DEFAULT_DESTINATION = r"C:\Users\yousu\Desktop\CARDV"
REGISTRY_PATH = Path(__file__).parent.parent / "data" / "processed_registry.json"


def get_camera_type(filename: str) -> str:
    """Determine camera type from filename."""
    match = VIDEO_PATTERN.match(filename)
    if not match:
        return "Unknown"

    file_id = int(match.group(2))
    suffix = match.group(3)

    if file_id < 53000:
        return "Movie_F" if suffix == 'A' else "Movie_R"
    else:
        return "Park_F" if suffix == 'A' else "Park_R"


def load_registry(registry_path: Path) -> Dict:
    """Load processed files registry."""
    if not registry_path.exists():
        print(f"ERROR: Registry not found at {registry_path}")
        print("Run build_initial_registry.py first!")
        raise FileNotFoundError(f"Registry not found: {registry_path}")

    with open(registry_path, 'r') as f:
        registry = json.load(f)

    return registry


def save_registry(registry: Dict, registry_path: Path):
    """Save updated registry with backup."""
    # Create backup of current registry
    if registry_path.exists():
        backup_path = registry_path.with_suffix('.json.backup')
        shutil.copy2(registry_path, backup_path)

    # Update timestamp
    registry['metadata']['last_updated'] = datetime.now().isoformat()

    # Save
    with open(registry_path, 'w') as f:
        json.dump(registry, f, indent=2)


def scan_source(source_path: Path) -> List[Path]:
    """
    Recursively scan source drive for all .MP4 files.

    Handles multiple external drive structures:
    - Flat (all files in root)
    - Organized (Movie_F/, Park_F/ folders)
    - DCIM style (DCIM/100__CAM/ folders)
    """
    print(f"\nScanning source: {source_path}")

    if not source_path.exists():
        print(f"ERROR: Source path not found: {source_path}")
        return []

    # Recursive search for all .MP4 files
    video_files = list(source_path.rglob("*.MP4"))
    video_files.extend(source_path.rglob("*.mp4"))

    print(f"Found {len(video_files)} video files")

    return video_files


def filter_new_files(
    source_files: List[Path],
    registry: Dict
) -> Tuple[List[Path], List[Path]]:
    """
    Separate files into new (to copy) and already-processed (to skip).

    Returns:
        (new_files, already_processed_files)
    """
    new_files = []
    already_processed = []

    processed_set = set(registry['processed_files'].keys())

    for file_path in source_files:
        if file_path.name in processed_set:
            already_processed.append(file_path)
        else:
            new_files.append(file_path)

    return new_files, already_processed


def copy_file_with_verification(
    source: Path,
    destination_dir: Path,
    auto_organize: bool = False
) -> Dict:
    """
    Copy file with integrity verification.

    Args:
        source: Source file path
        destination_dir: Destination directory
        auto_organize: If True, organize into Movie_F/, Park_F/ subdirectories

    Returns:
        Dict with copy result metadata
    """
    try:
        # Determine destination path
        if auto_organize:
            camera_type = get_camera_type(source.name)
            dest_folder = destination_dir / camera_type
            dest_folder.mkdir(parents=True, exist_ok=True)
            dest_path = dest_folder / source.name
        else:
            dest_path = destination_dir / source.name

        # Handle filename collision (shouldn't happen with timestamp naming)
        if dest_path.exists():
            # Check if it's actually the same file (same size)
            if dest_path.stat().st_size == source.stat().st_size:
                return {
                    'status': 'skip',
                    'reason': 'already_exists',
                    'source': str(source),
                    'destination': str(dest_path)
                }
            else:
                # Different file with same name - add suffix
                counter = 1
                while dest_path.exists():
                    dest_path = dest_path.parent / f"{dest_path.stem}_{counter:03d}{dest_path.suffix}"
                    counter += 1

        # Copy file
        start_time = time.time()
        shutil.copy2(source, dest_path)
        copy_time = time.time() - start_time

        # Verify integrity (size check)
        source_size = source.stat().st_size
        dest_size = dest_path.stat().st_size

        if source_size != dest_size:
            dest_path.unlink()  # Delete corrupted copy
            return {
                'status': 'error',
                'reason': 'size_mismatch',
                'source': str(source),
                'expected_size': source_size,
                'actual_size': dest_size
            }

        # Success
        return {
            'status': 'success',
            'source': str(source),
            'destination': str(dest_path),
            'size_bytes': source_size,
            'copy_time_s': round(copy_time, 2),
            'speed_mbps': round((source_size / (1024**2)) / copy_time, 2) if copy_time > 0 else 0,
            'timestamp': datetime.now().isoformat()
        }

    except Exception as e:
        return {
            'status': 'error',
            'reason': str(e),
            'source': str(source)
        }


def sync_files(
    source_files: List[Path],
    destination_dir: Path,
    registry: Dict,
    max_workers: int = 4,
    auto_organize: bool = False,
    dry_run: bool = False
) -> Dict:
    """
    Sync files with multi-threaded copying and progress tracking.

    Args:
        source_files: List of files to copy
        destination_dir: Destination directory
        registry: Processed files registry
        max_workers: Number of parallel copy threads
        auto_organize: Auto-organize by camera type
        dry_run: If True, only show what would be copied

    Returns:
        Sync report dictionary
    """
    print(f"\n{'[DRY RUN] ' if dry_run else ''}Syncing {len(source_files)} files...")
    print(f"Destination: {destination_dir}")
    print(f"Parallel workers: {max_workers}")
    if auto_organize:
        print("Auto-organize: Enabled (files sorted by camera type)")

    if dry_run:
        print("\nFiles that would be copied:")
        for i, file in enumerate(source_files[:10], 1):
            camera_type = get_camera_type(file.name)
            size_mb = file.stat().st_size / (1024**2)
            print(f"  {i}. {file.name} ({camera_type}, {size_mb:.1f} MB)")
        if len(source_files) > 10:
            print(f"  ... and {len(source_files) - 10} more files")
        return {'dry_run': True, 'total_files': len(source_files)}

    # Ensure destination exists
    destination_dir.mkdir(parents=True, exist_ok=True)

    # Sync tracking
    results = {
        'success': [],
        'skip': [],
        'error': []
    }

    start_time = time.time()
    total_bytes = 0

    # Multi-threaded copying
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all copy tasks
        future_to_file = {
            executor.submit(copy_file_with_verification, file, destination_dir, auto_organize): file
            for file in source_files
        }

        # Process completed tasks
        for i, future in enumerate(as_completed(future_to_file), 1):
            file = future_to_file[future]
            result = future.result()

            # Track result
            status = result['status']
            results[status].append(result)

            # Update registry on success
            if status == 'success':
                camera_type = get_camera_type(file.name)
                registry['processed_files'][file.name] = {
                    'filename': file.name,
                    'camera_type': camera_type,
                    'file_size_bytes': result['size_bytes'],
                    'location': str(destination_dir),
                    'first_seen': result['timestamp'],
                    'sync_date': datetime.now().date().isoformat()
                }

                # Update statistics
                registry['statistics']['by_camera'][camera_type] += 1
                registry['statistics']['total_count'] += 1
                total_bytes += result['size_bytes']

                # Save registry after each success (crash-safe)
                save_registry(registry, REGISTRY_PATH)

            # Progress
            print(f"[{i}/{len(source_files)}] {file.name}: {status.upper()}", end='')
            if status == 'success':
                print(f" ({result['speed_mbps']} MB/s)")
            else:
                print()

    # Final statistics
    elapsed_time = time.time() - start_time
    total_gb = total_bytes / (1024**3)
    avg_speed = (total_bytes / (1024**2)) / elapsed_time if elapsed_time > 0 else 0

    registry['statistics']['total_size_gb'] += total_gb

    return {
        'total_files': len(source_files),
        'successful': len(results['success']),
        'skipped': len(results['skip']),
        'errors': len(results['error']),
        'total_size_gb': round(total_gb, 2),
        'elapsed_time_s': round(elapsed_time, 2),
        'avg_speed_mbps': round(avg_speed, 2),
        'results': results
    }


def print_sync_report(report: Dict, already_processed_count: int):
    """Print sync summary report."""
    print("\n" + "="*70)
    print("SYNC REPORT")
    print("="*70)

    if report.get('dry_run'):
        print(f"DRY RUN: {report['total_files']} files would be copied")
        return

    print(f"Files found on source:     {report['total_files'] + already_processed_count}")
    print(f"Already processed (skip):  {already_processed_count}")
    print(f"New files to copy:         {report['total_files']}")
    print(f"")
    print(f"Successfully copied:       {report['successful']}")
    print(f"Skipped (duplicates):      {report['skipped']}")
    print(f"Errors:                    {report['errors']}")
    print(f"")
    print(f"Total copied:              {report['total_size_gb']} GB")
    print(f"Time elapsed:              {report['elapsed_time_s']:.1f} seconds")
    print(f"Average speed:             {report['avg_speed_mbps']} MB/s")

    # Show errors if any
    if report['errors'] > 0:
        print(f"\nERROR DETAILS:")
        for error in report['results']['error'][:5]:
            print(f"  - {Path(error['source']).name}: {error['reason']}")

    print("="*70)


def main():
    parser = argparse.ArgumentParser(
        description="Sync new dashcam files from external drive, skipping already processed files"
    )
    parser.add_argument(
        "--source",
        type=str,
        required=True,
        help="Source drive path (e.g., E:\\ or F:\\DCIM)"
    )
    parser.add_argument(
        "--destination",
        type=str,
        default=DEFAULT_DESTINATION,
        help=f"Destination directory (default: {DEFAULT_DESTINATION})"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        help="Number of parallel copy threads (default: 4)"
    )
    parser.add_argument(
        "--auto-organize",
        action="store_true",
        help="Auto-organize files into Movie_F/, Park_F/ subdirectories"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be copied without actually copying"
    )
    parser.add_argument(
        "--registry",
        type=str,
        default=str(REGISTRY_PATH),
        help="Path to processed files registry"
    )

    args = parser.parse_args()

    # Convert to Path objects
    source_path = Path(args.source)
    destination_path = Path(args.destination)
    registry_path = Path(args.registry)

    print("="*70)
    print("DASHCAM SYNC v1.0")
    print("="*70)

    # Load registry
    print(f"\nLoading registry: {registry_path}")
    registry = load_registry(registry_path)
    print(f"Registry contains {registry['statistics']['total_count']} processed files")

    # Scan source
    source_files = scan_source(source_path)

    if len(source_files) == 0:
        print("\nNo video files found on source drive!")
        return

    # Filter new vs already processed
    new_files, already_processed = filter_new_files(source_files, registry)

    print(f"\nFound {len(new_files)} NEW files to copy")
    print(f"Found {len(already_processed)} files already processed (will skip)")

    if len(new_files) == 0:
        print("\nNothing to sync - all files already processed!")
        return

    # Sync new files
    report = sync_files(
        new_files,
        destination_path,
        registry,
        max_workers=args.workers,
        auto_organize=args.auto_organize,
        dry_run=args.dry_run
    )

    # Save final registry
    if not args.dry_run:
        save_registry(registry, registry_path)

    # Print report
    print_sync_report(report, len(already_processed))

    print("\nSync complete!")


if __name__ == "__main__":
    main()
