# Dashcam Sync - Quick Start

**Smart file transfer for dashcam videos** - Automatically skip already-processed files.

## What It Does

Copies new dashcam videos from external drives to your working directory, intelligently skipping files that have already been processed (archived in your Drive folders).

**Key Features:**
- 🎯 **Smart filtering** - Only copies new files
- 🚀 **Fast** - Multi-threaded copying (4-8 parallel threads)
- 🛡️ **Safe** - Verifies integrity, crash-recoverable
- 📊 **Tracked** - Maintains registry of 15,998+ processed files

## Quick Start

### 1. Build Registry (First Time Only)

```bash
cd "G:\My Drive\PROJECTS\skills\dashcam-sync"
python scripts/build_initial_registry.py
```

**Output:**
```
Building initial processed files registry...
Total processed files: 15998
Total size: 1719.03 GB
Registry ready!
```

### 2. Sync New Files

**Basic sync from drive E:\:**
```bash
python scripts/sync_dashcam.py --source E:\
```

**Preview without copying (dry run):**
```bash
python scripts/sync_dashcam.py --source E:\ --dry-run
```

**Fast sync (8 threads):**
```bash
python scripts/sync_dashcam.py --source E:\ --workers 8
```

**Auto-organize by camera type:**
```bash
python scripts/sync_dashcam.py --source E:\ --auto-organize
```

## Example Output

```
======================================================================
DASHCAM SYNC v1.0
======================================================================
Loading registry: data/processed_registry.json
Registry contains 15998 processed files

Scanning source: E:\
Found 127 video files

Found 112 NEW files to copy
Found 15 files already processed (will skip)

Syncing 112 files...
Destination: C:\Users\yousu\Desktop\CARDV
Parallel workers: 4

[1/112] 20250727150654_052278A.MP4: SUCCESS (145.3 MB/s)
[2/112] 20250727150655_052279B.MP4: SUCCESS (152.1 MB/s)
...
[112/112] 20250810223045_053521A.MP4: SUCCESS (138.7 MB/s)

======================================================================
SYNC REPORT
======================================================================
Successfully copied:       110
Skipped (duplicates):      2
Errors:                    0

Total copied:              23.4 GB
Time elapsed:              156.3 seconds
Average speed:             153.2 MB/s
======================================================================
```

## Performance

| Scenario | Files | Size | Time |
|----------|-------|------|------|
| Small sync | 50 | 10 GB | 1-2 min |
| Medium sync | 200 | 40 GB | 5-8 min |
| Large sync | 500 | 100 GB | 12-18 min |

**Speed:** 100-150 MB/s typical (USB 3.0 drive, 4 workers)

## Command Options

| Option | Default | Description |
|--------|---------|-------------|
| `--source` | required | External drive path (e.g., `E:\`) |
| `--destination` | `C:\Users\yousu\Desktop\CARDV` | Destination folder |
| `--workers` | 4 | Parallel copy threads |
| `--auto-organize` | False | Sort into Movie_F/, Park_F/ folders |
| `--dry-run` | False | Preview without copying |

## How It Works

1. **Load registry** of 15,998 already-processed files
2. **Scan** external drive for all `.MP4` files (recursive)
3. **Filter** - Identify new files (not in registry)
4. **Copy** new files with multi-threaded speed
5. **Verify** integrity (file size check)
6. **Update** registry after each successful copy
7. **Report** summary

## Integration with Motion-Sampler

```bash
# 1. Sync new files from external drive
python skills/dashcam-sync/scripts/sync_dashcam.py --source E:\

# 2. Extract motion samples (10s intervals)
python skills/motion-sampler/scripts/extract_motion_samples.py
```

## Troubleshooting

**"Registry not found"**
→ Run `python scripts/build_initial_registry.py` first

**"No video files found"**
→ Check drive letter: `ls E:\` or `dir E:\`

**"All files already processed"**
→ This is expected if you've synced this drive before

**Slow speed (<50 MB/s)**
→ Try fewer workers: `--workers 2`

## File Structure

```
dashcam-sync/
├── scripts/
│   ├── build_initial_registry.py  # One-time setup
│   └── sync_dashcam.py            # Main sync script
├── data/
│   └── processed_registry.json    # 15,998 processed files
└── skill.md                        # Full documentation
```

## Dependencies

**None!** Uses Python standard library only.

**Requirements:** Python 3.8+

## Camera Types

Files are auto-detected by filename pattern:

| Pattern | Camera Type |
|---------|-------------|
| `_0512XXA.MP4` (ID < 53000, suffix A) | Movie_F (driving, front) |
| `_0512XXB.MP4` (ID < 53000, suffix B) | Movie_R (driving, rear) |
| `_0555XXA.MP4` (ID ≥ 53000, suffix A) | Park_F (parked, front) |
| `_0707XXB.MP4` (ID ≥ 53000, suffix B) | Park_R (parked, rear) |

## Next Steps

- **Test:** Try `--dry-run` first to preview
- **Sync:** Run without `--dry-run` to copy files
- **Process:** Use motion-sampler or other skills on synced files
- **Archive:** Move processed files to Drive folders (manual for now)

## Full Documentation

See `skill.md` for complete documentation including:
- Natural language interface
- Advanced features
- Error handling
- Performance benchmarks
- Roadmap (v1.5, v2.0)

**Version:** 1.0
**Status:** ✅ Production Ready
