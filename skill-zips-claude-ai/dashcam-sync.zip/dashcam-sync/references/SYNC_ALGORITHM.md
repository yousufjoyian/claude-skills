# Sync Algorithm - Technical Reference

## Overview

The dashcam sync algorithm uses filename-based filtering with a persistent registry to identify and copy only new files from external drives, ensuring no re-processing of already-handled videos.

## Core Algorithm

### High-Level Workflow

```
┌─────────────────┐
│ Load Registry   │ (15,998 processed files)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Scan Source     │ (Recursive .MP4 search)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Filter New      │ (Filename lookup in registry)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Multi-threaded  │ (4-8 parallel workers)
│ Copy Loop       │
└────────┬────────┘
         │
         ├─► Copy file (shutil.copy2)
         ├─► Verify integrity (size check)
         ├─► Update registry (atomic)
         ├─► Report progress
         │
         ▼
┌─────────────────┐
│ Generate Report │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Save Registry   │ (With backup)
└─────────────────┘
```

## Detailed Steps

### 1. Load Registry

```python
def load_registry(registry_path: Path) -> Dict:
    """
    Load processed files registry from JSON.

    Registry contains:
    - 15,998 filenames (keys)
    - Metadata per file (camera type, size, location)
    - Statistics (total count, size, camera breakdown)
    """
    if not registry_path.exists():
        raise FileNotFoundError("Run build_initial_registry.py first")

    with open(registry_path, 'r') as f:
        registry = json.load(f)

    return registry
```

**Time complexity:** O(n) where n = registry size (~16K files)
**Memory usage:** ~5 MB for 16K files

### 2. Scan Source

```python
def scan_source(source_path: Path) -> List[Path]:
    """
    Recursively find all .MP4 files on source drive.

    Handles multiple drive structures:
    - Flat: E:\*.MP4
    - Organized: E:\Movie_F\*.MP4, E:\Park_F\*.MP4
    - DCIM: E:\DCIM\100__CAM\*.MP4
    """
    video_files = []

    # Case-insensitive recursive search
    video_files.extend(source_path.rglob("*.MP4"))
    video_files.extend(source_path.rglob("*.mp4"))

    return video_files
```

**Time complexity:** O(m) where m = total files on drive
**Optimization:** Uses `rglob` (fast recursive glob)

**Example:**
```
Source drive E:\ contains:
- E:\Movie_F\20250727150654_052278A.MP4
- E:\Movie_F\20250727150655_052279B.MP4
- E:\DCIM\100__CAM\20250728110511_052630A.MP4
- E:\Document.pdf (ignored)

Result: 3 video files found
```

### 3. Filter New Files

```python
def filter_new_files(
    source_files: List[Path],
    registry: Dict
) -> Tuple[List[Path], List[Path]]:
    """
    Separate files into:
    - new_files: Not in registry (need to copy)
    - already_processed: In registry (skip)
    """
    new_files = []
    already_processed = []

    # Convert registry to set for O(1) lookup
    processed_set = set(registry['processed_files'].keys())

    for file_path in source_files:
        if file_path.name in processed_set:
            already_processed.append(file_path)
        else:
            new_files.append(file_path)

    return new_files, already_processed
```

**Time complexity:** O(m) where m = files on source drive
**Optimization:** Set lookup is O(1) vs O(n) for list

**Example:**
```
Source files: 127
Registry: 15,998 processed files

Lookup results:
- Already processed: 15 files (in registry)
- New files: 112 files (not in registry) → COPY THESE
```

### 4. Multi-Threaded Copy Loop

```python
def sync_files(
    source_files: List[Path],
    destination_dir: Path,
    registry: Dict,
    max_workers: int = 4
) -> Dict:
    """
    Copy files in parallel with progress tracking.
    """
    results = {'success': [], 'skip': [], 'error': []}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        future_to_file = {
            executor.submit(copy_file_with_verification, file, destination_dir): file
            for file in source_files
        }

        # Process completed tasks
        for future in as_completed(future_to_file):
            result = future.result()

            if result['status'] == 'success':
                # Update registry immediately (crash-safe)
                registry['processed_files'][file.name] = {...}
                save_registry(registry)
```

**Time complexity:** O(k × t) where:
- k = number of files
- t = time per file (depends on size and drive speed)

**Parallelization:**
- 4 workers → ~4x speedup (on multi-core CPU + fast I/O)
- Diminishing returns beyond 6-8 workers

**Example (4 workers, 112 files):**
```
Worker 1: File 1  → File 5  → File 9  → ...
Worker 2: File 2  → File 6  → File 10 → ...
Worker 3: File 3  → File 7  → File 11 → ...
Worker 4: File 4  → File 8  → File 12 → ...

Total time: ~2m 45s (vs ~11m single-threaded)
Speedup: 4x
```

### 5. Copy with Verification

```python
def copy_file_with_verification(
    source: Path,
    destination_dir: Path
) -> Dict:
    """
    Copy file and verify integrity.
    """
    # Determine destination path
    dest_path = destination_dir / source.name

    # Handle filename collision
    if dest_path.exists():
        if dest_path.stat().st_size == source.stat().st_size:
            return {'status': 'skip', 'reason': 'already_exists'}
        else:
            # Different file, rename: file_001.MP4, file_002.MP4
            counter = 1
            while dest_path.exists():
                dest_path = dest_path.parent / f"{dest_path.stem}_{counter:03d}{dest_path.suffix}"
                counter += 1

    # Copy with metadata preservation
    start_time = time.time()
    shutil.copy2(source, dest_path)  # Preserves timestamps
    copy_time = time.time() - start_time

    # Verify integrity (size check)
    source_size = source.stat().st_size
    dest_size = dest_path.stat().st_size

    if source_size != dest_size:
        dest_path.unlink()  # Delete corrupted copy
        return {'status': 'error', 'reason': 'size_mismatch'}

    # Success
    return {
        'status': 'success',
        'size_bytes': source_size,
        'copy_time_s': copy_time,
        'speed_mbps': (source_size / (1024**2)) / copy_time
    }
```

**Verification strategy:**
- **v1.0:** Size check only (fast, catches most issues)
- **v2.0 (planned):** Optional SHA256 hash check (slower, more thorough)

**Why size-only verification is sufficient:**
1. **Corruption detection:** Size mismatch indicates incomplete copy
2. **Speed:** No need to re-read entire file
3. **Reliability:** Modern file systems (NTFS, ext4) have checksums

**When hash verification is needed:**
- Critical data (medical, legal)
- Unreliable drives (suspect bad sectors)
- Network copies (higher corruption risk)

### 6. Registry Update (Atomic)

```python
def save_registry(registry: Dict, registry_path: Path):
    """
    Save registry with atomic update and backup.
    """
    # 1. Create backup of current registry
    if registry_path.exists():
        backup_path = registry_path.with_suffix('.json.backup')
        shutil.copy2(registry_path, backup_path)

    # 2. Update timestamp
    registry['metadata']['last_updated'] = datetime.now().isoformat()

    # 3. Write to temporary file first (atomic on POSIX, near-atomic on Windows)
    temp_path = registry_path.with_suffix('.json.tmp')
    with open(temp_path, 'w') as f:
        json.dump(registry, f, indent=2)

    # 4. Atomic rename (overwrites registry_path)
    temp_path.replace(registry_path)
```

**Crash safety:**
- Registry saved **after each successful copy**
- If process crashes, registry reflects all completed copies
- Re-running sync will resume from last successful copy

**Example crash scenario:**
```
Files to copy: 112
Copied successfully: 67
[CRASH - power loss]

Registry state: 67 files added
Re-run sync: Detects 67 as already-processed, copies remaining 45
Result: No duplicates, all 112 files eventually copied
```

## Camera Type Detection

### Algorithm

```python
def get_camera_type(filename: str) -> str:
    """
    Extract camera type from filename.

    Pattern: YYYYMMDDHHMMSS_XXXXXXA/B.MP4
              ^14 digits    ^6-digit ID ^suffix
    """
    # Validate pattern
    match = re.match(r'^(\d{14})_(\d{6})([AB])\.MP4$', filename, re.IGNORECASE)
    if not match:
        return "Unknown"

    # Extract components
    timestamp = match.group(1)  # YYYYMMDDHHMMSS
    file_id = int(match.group(2))  # 051234
    suffix = match.group(3)  # A or B

    # Determine camera type
    if file_id < 53000:
        camera_mode = "Movie"  # Driving mode
    else:
        camera_mode = "Park"   # Parking mode

    if suffix == 'A':
        camera_position = "F"  # Front
    else:
        camera_position = "R"  # Rear

    return f"{camera_mode}_{camera_position}"
```

### Decision Tree

```
Filename: 20250727150654_052278A.MP4
                          ^^^^^^ ^
                          ID     Suffix

ID < 53000? YES → Movie mode
Suffix == 'A'? YES → Front camera
Result: Movie_F
```

```
Filename: 20251006142644_070785B.MP4
                          ^^^^^^ ^
                          ID     Suffix

ID < 53000? NO → Park mode
Suffix == 'A'? NO → Rear camera
Result: Park_R
```

### Validation Test Cases

| File ID | Suffix | Expected Type | Test Result |
|---------|--------|---------------|-------------|
| 051234  | A      | Movie_F       | ✓ Pass      |
| 052999  | B      | Movie_R       | ✓ Pass      |
| 053000  | A      | Park_F        | ✓ Pass      |
| 070785  | B      | Park_R        | ✓ Pass      |
| 052999  | C      | Unknown       | ✓ Pass (invalid suffix) |

## Performance Analysis

### Time Complexity

| Operation | Complexity | Notes |
|-----------|------------|-------|
| Load registry | O(n) | n = 16K files, ~5 MB JSON |
| Scan source | O(m) | m = files on drive |
| Filter new files | O(m) | Set lookup O(1) per file |
| Copy files | O(k × t) | k = new files, t = copy time |
| Save registry | O(n) | JSON serialization |

**Total:** O(m + k×t) dominated by copy time

### Space Complexity

| Component | Memory Usage |
|-----------|--------------|
| Registry in memory | ~5 MB (16K files) |
| File list | ~1 KB per 100 files |
| Worker threads | ~50 MB × num_workers |
| Total peak | ~200 MB (4 workers) |

**Scalability:**
- Registry grows linearly: 1K files ≈ 320 KB
- 100K files ≈ 32 MB (still manageable)
- Beyond 100K: Consider database (SQLite)

### I/O Patterns

**Read (source drive):**
- Sequential read of video files
- Cache hit rate: Low (each file read once)
- Optimal for: Sequential access drives (HDD, SSD)

**Write (destination):**
- Many parallel writes (4-8 streams)
- Random write pattern (if auto-organize enabled)
- Optimal for: SSD (handles parallel writes well)

**Registry:**
- Small writes after each file (~5 KB update)
- Frequent but minimal I/O overhead

## Bottleneck Analysis

### Current Bottleneck: I/O Bandwidth

**USB 3.0 drive (typical):**
```
Read speed: 100-150 MB/s
Workers: 4
Per-worker speed: 25-37 MB/s
Bottleneck: USB bandwidth

Increasing workers beyond 4: Minimal gain
```

**Internal SSD (fast):**
```
Read/write speed: 500+ MB/s
Workers: 8
Per-worker speed: 60-80 MB/s
Bottleneck: Python GIL (for JSON serialization)

Increasing workers beyond 8: Diminishing returns
```

**Network drive (slow):**
```
Read/write speed: 30-50 MB/s
Workers: 2-4
Bottleneck: Network latency + bandwidth

Increasing workers: Can make it WORSE (contention)
```

### Optimization Opportunities

**Current (v1.0):**
```python
# Registry saved after EACH file
for file in files:
    copy_file(file)
    registry['processed_files'][file.name] = {...}
    save_registry(registry)  # 5 KB write per file
```

**Optimized (v1.5 planned):**
```python
# Batch registry updates every 10 files
batch = []
for i, file in enumerate(files):
    copy_file(file)
    batch.append(file)

    if len(batch) >= 10 or i == len(files) - 1:
        update_registry_batch(registry, batch)
        save_registry(registry)  # 5 KB write per 10 files
        batch = []
```

**Expected improvement:** 10x fewer registry writes, ~5-10% faster overall

## Error Handling Strategies

### Error Categories

**Fatal errors (stop sync):**
1. Registry not found → User must build it first
2. Source drive not accessible → Wrong path or drive unplugged
3. Destination disk full → Cannot continue

**Non-fatal errors (continue sync):**
1. Single file copy failure → Skip, report error
2. Single file verification failure → Delete partial, report error
3. Permission denied on one file → Skip, report error

### Error Recovery

**Scenario 1: Mid-sync crash**
```
Before:
- Registry: 15,998 files
- External drive: 127 files (15 already processed, 112 new)

During sync:
- Copied 67 files
- Registry updated with 67 new entries (16,065 total)
[CRASH]

Recovery:
- Re-run sync
- Load registry: 16,065 files (includes the 67 copied)
- Scan source: 127 files
- Filter: 60 new files (112 - 67 + 15 already processed)
- Copy remaining 60 files
```

**Scenario 2: Corrupted registry**
```
Error: "JSON decode error"

Recovery:
1. Restore from backup: cp processed_registry.json.backup processed_registry.json
2. If backup also corrupted: Rebuild from scratch
   python scripts/build_initial_registry.py
```

## Future Enhancements

### v1.5: Batch Registry Updates
- Update registry every 10 files instead of every file
- Trade-off: Faster (fewer writes) vs. Less crash-safe (lose up to 10 files)
- Configurable: `--batch-size 10`

### v2.0: Hash-Based Deduplication
```python
# Current: Filename-based
if filename in registry:
    skip()

# v2.0: Hash-based
file_hash = calculate_sha256(file)
if file_hash in registry:
    skip()  # Catches renamed files
```

**Benefit:** Detect renamed files, true deduplication
**Cost:** Must read entire file to hash (~2-3x slower)

### v2.5: Database Backend
```python
# Current: JSON file
registry = json.load(open('registry.json'))

# v2.5: SQLite database
db = sqlite3.connect('registry.db')
db.execute("SELECT * FROM files WHERE filename = ?", (filename,))
```

**Benefit:** Faster lookups for >50K files, concurrent access
**Cost:** More complex setup

## Conclusion

The sync algorithm achieves:
- **Correctness:** No duplicates, all new files copied
- **Performance:** 100-150 MB/s typical (USB 3.0, 4 workers)
- **Reliability:** Crash-safe, error-resilient
- **Simplicity:** No external dependencies, pure Python stdlib

**Key innovations:**
1. Persistent registry (16K files tracked)
2. Set-based filtering (O(1) lookup)
3. Multi-threaded copying (4x speedup)
4. Atomic registry updates (crash-safe)
5. Size-based verification (fast, reliable)

**Trade-offs accepted:**
- Filename-based (not hash-based) → Faster but won't detect renames
- Size-only verification (not hash) → Faster but less thorough
- Per-file registry update → Slower but crash-safe

**v1.0 is optimal for:**
- 1-50K files
- USB/internal drives
- Standard use cases (sync new dashcam footage)

**Future versions needed for:**
- >50K files → Database backend (v2.5)
- Unreliable drives → Hash verification (v2.0)
- Cloud sync → Network optimization (v2.0)
