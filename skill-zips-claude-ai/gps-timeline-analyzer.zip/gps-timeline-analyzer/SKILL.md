---
name: gps-timeline-analyzer
description: Transforms raw GPS data from Google Timeline and Snapchat exports into accurate human-readable daily timelines with complete temporal accountability. This skill should be used when users request GPS timeline analysis, want to analyze location history, mention Google Timeline/Snapchat location/GPS data, ask about movements on specific dates, or need to generate location reports.
---

# GPS Timeline Analyzer

**Skill Type:** Data Processing & Analysis
**Domain:** Location Intelligence, Geospatial Analysis, Temporal Pattern Recognition
**Version:** 2.3
**Last Updated:** 2025-10-26

---

## Description

Transforms raw GPS data from Google Timeline and Snapchat exports into accurate, human-readable daily timelines with complete temporal accountability. Uses forensic-grade analysis with source prioritization, cached coordinate detection, and minute-by-minute coverage tracking.

**When to Use This Skill:**
- User requests GPS timeline analysis
- User wants to analyze location history
- User mentions "Google Timeline", "Snapchat location", or "GPS data"
- User asks about their movements on specific dates
- User needs to generate location reports

---

## Quick Start

### User Trigger Phrases
- "Analyze my GPS timeline for [date]"
- "Generate a location report for [date range]"
- "Where was I on [date]?"
- "Unify my Google and Snapchat location data"
- "Create a detailed timeline from my GPS exports"

### Expected Inputs
1. **Google Timeline JSON** (required) - Export from Google Takeout
2. **Date Range** (required) - Single day, range, or "all available"
3. **Snapchat JSON** (optional) - Snapchat location history export
4. **Output Directory** (optional) - Default: `./reports/`

### Expected Outputs
- Detailed timeline text file with minute-by-minute accountability
- Coverage statistics (% of time with valid data)
- Gap analysis (missing periods explicitly marked)
- Source transparency (Google vs Snapchat labeling)
- Investigation tags for anomalies

---

## Core Capabilities

### 1. User Input Acquisition (Section 0 Protocol)

**CRITICAL: Always follow the Section 0 protocol before processing.**

#### Step 1: Parse User Request
```
User: "Analyze my GPS data for August 14, 2025"

AI Detection:
✅ Date detected: 2025-08-14
❌ File path not specified → Try auto-discovery
```

#### Step 2: Auto-Discovery
Search these locations in order:
1. `GPS_By_Year/JSON_RAW/*.json`
2. `./GPS Visits *.json`
3. `../GPS_By_Year/JSON_RAW/*.json`
4. `snapchat/location_history.json`

#### Step 3: Validate Files
```python
def validate_google_timeline(file_path):
    # Check file exists
    # Parse JSON
    # Verify 'semanticSegments' key exists
    # Report segment count and date range
```

#### Step 4: Prompt for Missing Inputs
If files not found:
```
📍 I need Google Timeline data to analyze. I couldn't find it in the expected location.

Please provide ONE of the following:
1. **Direct file path**: e.g., `G:\My Drive\...\GPS Visits 2025.json`
2. **Directory to search**: I'll find all GPS files
3. **Navigate me**: Tell me the folder path

💡 Tip: Google Timeline exports are usually named "GPS Visits [YEAR].json"
```

#### Step 5: Configuration Summary & Confirmation
```
📋 **Analysis Configuration Summary**

**Data Sources:**
✅ Google Timeline: GPS Visits 2025.json (1,247 segments)
✅ Snapchat: location_history.json (3,421 records)

**Date Range:**
📅 Single day: 2025-08-14

**Output:**
💾 Directory: ./reports/
📄 Format: Detailed timeline with v2.3 header

Ready to proceed? (Yes/No)
```

**NEVER begin processing without user confirmation.**

---

### 2. Data Processing (V8.2 Core Logic)

#### A. Source Prioritization (NEVER Average Across Sources)

```python
# ✅ CORRECT: Hierarchical trust order
1. Google GPS/Wi-Fi breadcrumbs (7-decimal precision, ±1-3m)
2. Google Visit anchors (7-decimal precision, ±10-50m)
3. Snapchat hourly data (3-4 decimal precision, ±100-300m)
4. Cell-only (±200m-2km, low confidence)

# ❌ WRONG: Averaging destroys precision
avg_lat = sum(all_points) / len(all_points)  # NO!
```

**Why:** Mixing 7-decimal Google (±1m) with 3-decimal Snapchat (±100m) produces ~60m errors.

#### B. Complete Data Extraction

Extract from Google Timeline JSON:
1. **Activity Segments** → GPS breadcrumbs (timelinePath)
2. **Visit Segments** → Place anchors (visit.topCandidate.placeLocation)

Both are required for complete coverage.

#### C. Visit-Aware Clustering

Parameters:
- `movement_threshold_m = 150` (cluster points within 150m)
- `max_gap_min = 70` (maximum 70-minute gap in same stay)
- `visit_merge_distance_m = 300` (merge visit markers with breadcrumbs)
- `visit_merge_time_min = 1` (if <1 minute apart)

#### D. Cached Coordinate Detection

```python
def detect_cached_coordinates(points):
    """
    Identify repeated coordinates that pollute data quality.

    Criteria:
    - Same lat/lon appears >5 times
    - Within 60-minute window
    - Flat accuracy (unchanged)
    - Same source (or source bouncing)
    """
```

#### E. 24-Hour Accountability

Every timeline MUST account for all time:
- **Known periods:** Actual GPS data with confidence markers
- **Gap periods:** Explicitly marked as:
  - ❌ NO DATA: Complete absence
  - ❓ DATA GAP: Partial missing hours
  - 📵 DEVICE OFF: Confirmed powered down

#### F. DST Handling (v2.2)

Support 23-hour (spring forward) and 25-hour (fall back) days:
```python
def get_day_duration_minutes(date):
    # Normal day: 1440 minutes
    # Spring forward: 1380 minutes (23 hours)
    # Fall back: 1500 minutes (25 hours)
```

#### G. Cross-Day Visit Linking (v2.2)

When visits cross midnight, link them with shared `visit_id`:
```
# Day 1 (2025-09-07):
23:15 PM - 24:00 (45 min)
  Note: Visit continues to next day (cross_day_id: visit_abc123)

# Day 2 (2025-09-08):
00:00 - 01:20 AM (1.3 hr)
  Note: Continued from previous day (cross_day_id: visit_abc123)
```

---

### 3. Output Generation

#### Format: Detailed Timeline Report

```
======================================================================
Generated by: GPS Timeline Analysis System v2.3
Specification: TECHNICAL_SPECIFICATION_V2.3.md
Code version: [git commit hash]
Parameters: movement_threshold=150m, max_gap=70min, visit_merge=300m/1min
Generated: 2025-10-26T14:32:15-04:00 EDT
======================================================================

ONE-LINE OVERVIEW
Home overnight → early-afternoon car hop east...

======================================================================
DETAILED TIMELINE
======================================================================

00:00–13:58 — Home (parcel jitter only)
  43.8757328, -79.0530459 (Home - 15m, within radius) [from GOOGLE]
  GPS points: 45 (GOOGLE, SNAPCHAT)
  Confidence: CONFIRMED

[GAP] 13:58–14:04
      No GPS data (6 minutes)

14:04:20–14:13:08 — Visit in Kingston/Whites belt (≈8 m 48 s)
  43.880023, -79.026765 [from GOOGLE_VISIT]
  Snap corroboration: 14:11:44 EDT at 43.880, -79.026
  GPS points: 3 (GOOGLE_VISIT, SNAPCHAT)
  Confidence: CONFIRMED

...

======================================================================
TRANSPARENCY
======================================================================

DATA QUALITY:
  Total GPS points: 187
  Malformed/skipped: 0
  Duplicates removed: 0

COVERAGE:
  Day duration: 1440 minutes (24 hours)
  Covered: 1440 minutes (100%)
  Gap time: 0 minutes (0%)

COVERAGE BY SOURCE:
  Google: 76.2% of day (1097 min)
  Snapchat: 18.4% of day (265 min)
  Overlap: 12.1% of day (174 min)

STAYS:
  CONFIRMED: 8 (88.9%)
  AMBIGUOUS [?]: 1 (11.1%)
  CACHED [CACHED DATA]: 0 (0%)

INVESTIGATION TAGS:
  None (clean day)
```

#### Confidence Markers

- **(no marker)** = CONFIRMED stay (≥3 points OR ≥10 min OR multiple sources)
- **[?]** = AMBIGUOUS stay (single point OR brief duration)
- **[CACHED DATA]** = Cached data quality issue (suspect)

#### Investigation Tags (Searchable)

- `[INV:TELEPORT]` - GPS jump after gap (impossible speed)
- `[INV:POI_SNAP]` - POI coordinate with no breadcrumbs
- `[INV:CELL_ONLY]` - Cell tower only (low confidence)
- `[INV:REGULAR_INTERVAL]` - Suspiciously regular timestamps
- `[INV:CARRYOVER]` - Last-known location after gap
- `[INV:SPEED_ANOMALY]` - Impossible travel speed
- `[INV:MALFORMED_DATA]` - Data quality issues

---

## Implementation Guide

### Phase 1: Input Acquisition

```python
# 1. Detect explicit inputs from user message
inputs = parse_user_request(user_message)

# 2. Auto-discover missing inputs
if not inputs['google_timeline']:
    inputs['google_timeline'] = auto_discover_google_timeline()

# 3. Validate all inputs
validate_google_timeline(inputs['google_timeline'])
validate_date_range(inputs['date_range'])

# 4. Prompt for missing required inputs
if missing_required_inputs:
    prompt_user_for_inputs()

# 5. Present configuration summary
show_configuration_summary(inputs)

# 6. Wait for confirmation
if not user_confirms():
    return  # Do not proceed
```

### Phase 2: Data Loading

```python
# 1. Load Google Timeline JSON
google_data = load_json(google_timeline_path)

# 2. Load Snapchat JSON (if provided)
snapchat_data = load_json(snapchat_path) if snapchat_path else None

# 3. Extract GPS points for date range
google_points = extract_google_points(google_data, date_range)
snapchat_points = extract_snapchat_points(snapchat_data, date_range)

# 4. Combine and sort by timestamp
all_points = sorted(google_points + snapchat_points, key=lambda p: p['time'])
```

### Phase 3: Data Quality

```python
# 1. Validate and clean points
quality_log = DataQualityLog()
cleaned_points, quality_log = validate_and_clean_points(all_points, quality_log)

# 2. Detect cached coordinates
cached_coords = detect_cached_coordinates_v2_2(cleaned_points)

# 3. Filter cached before clustering
good_points = [p for p in cleaned_points
               if not cached_coords.get((p['lat'], p['lon']), False)]
```

### Phase 4: Clustering

```python
# 1. Cluster GPS points into stays
stays = cluster_stays(good_points, movement_threshold_m=150, max_gap_min=70)

# 2. Split stays at midnight
stays = split_stays_at_midnight(stays)

# 3. Select best coordinate for each stay
for stay in stays:
    stay['location'] = select_best_coordinate_v8_2(stay['points'])
    stay['confidence'] = classify_stay_confidence(stay)
```

### Phase 5: Timeline Construction

```python
# 1. Build complete 24-hour timeline
timeline = []

for i, stay in enumerate(stays):
    # Add gap before this stay if needed
    if i > 0:
        gap_duration = (stay['start_time'] - stays[i-1]['end_time']).total_seconds() / 60
        if gap_duration >= 1:
            timeline.append({
                'type': 'GAP',
                'start_time': stays[i-1]['end_time'],
                'end_time': stay['start_time'],
                'duration_min': gap_duration
            })

    # Add stay
    timeline.append(stay)

# 2. Check for gap at start of day
# 3. Check for gap at end of day
```

### Phase 6: Report Generation

```python
# 1. Generate header
report = generate_report_header(PARAMS_V2_3)

# 2. Generate one-line overview
report += generate_overview(timeline)

# 3. Generate detailed timeline
for item in timeline:
    if item['type'] == 'GAP':
        report += format_gap(item)
    else:
        report += format_stay(item)

# 4. Generate transparency section
report += generate_transparency_section(
    quality_log,
    coverage_stats,
    source_breakdown,
    confidence_breakdown
)

# 5. Save to file
output_path = save_report(report, output_dir, date)
```

### Phase 7: Completion

```python
# 1. Report output location to user
print(f"✅ Complete! Report saved to: {output_path}")

# 2. Provide summary statistics
print(f"   Coverage: {coverage_pct}%")
print(f"   GPS points: {total_points}")
print(f"   Stays: {len(stays)} ({confirmed_count} confirmed)")
```

---

## Reference Materials

### In This Skill

- **references/TECHNICAL_SPECIFICATION_V2.3.md** - Complete technical specification with all rules A-K
- **scripts/unified_timeline_v2_3.py** - Main processing script
- **scripts/coordinate_selection.py** - V8.2 coordinate selection logic
- **scripts/visit_clustering.py** - Clustering and visit reconciliation
- **scripts/input_validation.py** - User input acquisition protocol
- **assets/placebook_template.json** - Place book configuration template
- **assets/late_night_exceptions_template.json** - Late-night exceptions template
- **assets/params_v2_3.json** - Default parameters

### External Documentation

- Google Timeline JSON structure documentation
- Snapchat location history format
- Haversine distance formula

---

## Tunable Parameters (v2.3)

```json
{
  "movement_threshold_m": 150,
  "max_gap_min": 70,
  "visit_merge_distance_m": 300,
  "visit_merge_time_min": 1,
  "late_night_start": "22:00",
  "late_night_end": "04:00",
  "cache_repeat_threshold": 5,
  "cache_time_window_min": 60,
  "vehicle_min_speed": 8,
  "hysteresis_intervals": 2,
  "teleport_gap_threshold_min": 20
}
```

---

## Common Issues & Solutions

### Issue 1: "No GPS data found for date"

**Cause:** Date outside available data range OR device was off
**Solution:**
1. Check available date range in file
2. Try adjacent dates
3. Generate report noting the gap

### Issue 2: "Averaged coordinates from different sources"

**Cause:** Old V7 logic used instead of V8.2
**Solution:**
- NEVER average Google + Snapchat together
- Use hierarchical source prioritization
- Filter cached coordinates BEFORE selecting best point

### Issue 3: "Visit showing 0-minute duration"

**Cause:** Visit marker not merged with nearby breadcrumbs
**Solution:**
- Check visit_merge_distance_m (should be 300m)
- Check visit_merge_time_min (should be 1 min)
- Verify visit clustering is enabled

### Issue 4: "Missing hours in timeline"

**Cause:** Gaps not explicitly marked
**Solution:**
- Ensure gap detection is enabled
- Check day-start and day-end gap detection
- Verify 24-hour accountability is enforced

### Issue 5: "DST day shows wrong coverage percentage"

**Cause:** Using 1440 minutes for all days
**Solution:**
- Use `get_day_duration_minutes(date)` function
- Check for DST transitions (spring/fall)
- Calculate coverage against actual day duration

---

## Security & Privacy Notes

### Data Sensitivity

GPS timeline data is **highly personal and sensitive**:
- Contains precise location history
- Reveals daily routines and patterns
- May include home/work addresses
- Can identify relationships and associations

### Processing Guidelines

1. **Local Processing Only** - Never upload GPS data to external services
2. **File Permissions** - Ensure output files have appropriate read/write restrictions
3. **Anonymization** - Consider redacting addresses in shared reports
4. **Retention** - Delete processed files when no longer needed

### Investigation Tags

The system detects fabrication patterns but:
- ❌ NOT an anti-forensics tool
- ❌ Sophisticated spoofing can evade detection
- ✅ All conclusions require independent corroboration
- ✅ Designed for legitimate personal data analysis

---

## Skill Invocation

This skill is invoked when the model detects:
1. User mentions "GPS timeline", "location history", or "Google Timeline"
2. User requests analysis of movement patterns or location data
3. User provides paths to GPS export files
4. User asks "where was I on [date]?"

---

## Success Criteria

A successful GPS timeline analysis must:

✅ Obtain all required inputs from user (Google Timeline JSON, date range)
✅ Validate all inputs before processing
✅ Present configuration summary and get confirmation
✅ Process data using V8.2 logic (source prioritization, never averaging)
✅ Generate complete 24-hour timeline with gap notation
✅ Include transparency section (coverage, quality, confidence breakdown)
✅ Save report to confirmed output location
✅ Report output file path to user

**Key Principle:** Never guess or assume critical inputs. Always validate and confirm before processing.

---

## Version History

- **v2.3** (2025-10-26) - Added User Input Acquisition Protocol (Section 0)
- **v2.2** (2025-10-26) - Airtight improvements (DST, cross-day, malformed data)
- **v2.1** (2025-10-26) - Canonical rules A-J, pipeline, tunable parameters
- **v2.0** (2025-10-26) - Initial V8.2 unified specification
- **v8.2** - Visit clustering fix (300m threshold)
- **v8.1** - Visit segment extraction
- **v8.0** - Source prioritization (never average)
- **v1-v7** - Deprecated (averaging issues)

---

**Last Updated:** 2025-10-26
**Status:** Production Ready
**Maintained By:** GPS Timeline Analysis System Project
