#!/usr/bin/env python3
"""
Generate August 14, 2025 Complete 24-Hour Timeline
Uses GPS breadcrumbs from Google Timeline + Snapchat to ensure full coverage

Based on the established pattern from august_14_corrected_with_snap.py
"""

import json
import math
import sys
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Tuple, Optional
from pathlib import Path
from collections import defaultdict

# Add path for GPS data loading
sys.path.insert(0, str(Path(__file__).parent))
from comprehensive_analysis import load_gps_data, filter_segments_from_date

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two GPS coordinates in meters."""
    R = 6371000  # Earth's radius in meters
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)

    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad

    a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    return R * c

def parse_timestamp(timestamp_str: str) -> Optional[datetime]:
    """Parse various timestamp formats to datetime object."""
    if not timestamp_str:
        return None
    try:
        return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
    except:
        return None

def parse_coordinates(coord_str: str) -> Optional[Tuple[float, float]]:
    """Parse coordinate string like '43.8757311°, -79.0530574°' into lat, lon."""
    try:
        coord_str = coord_str.replace('°', '').replace(' ', '')
        parts = coord_str.split(',')
        if len(parts) == 2:
            lat = float(parts[0])
            lon = float(parts[1])
            return lat, lon
    except:
        pass
    return None

# Known location mappings
KNOWN_LOCATIONS = {
    (43.883764, -79.045873): "No Frills Williamson",
    (43.8840889, -79.0454892): "No Frills Williamson",
    (43.8845, -79.0458): "Shoppers Drug Mart Williamson",
    (43.8757778, -79.0529314): "38 Down Crescent (HOME)",
    (43.875747, -79.0530565): "38 Down Crescent (HOME)",
    (43.8713559, -79.0335882): "Pickering Bondar Classy Class",
    (43.441428, -79.684880): "312 Maurice Dr",
    (43.8653184, -79.020062): "Costco Ajax",
    (43.8610, -79.0514): "28 Griffiths Dr (Anum house)",
    (43.9109, -79.6192): "4970 King St (Najilas Farm)",
    (43.8644, -79.0802): "Saint Wilfred Catholic School",
    # Additional common locations
    (43.8848, -79.0469): "202 Williamson Dr",
    (43.8877, -79.0470): "22 Searell Ave",
    (43.8794435, -79.0510293): "22 Searell Ave"
}

def get_address_for_coordinates(lat: float, lon: float, threshold_m: float = 50) -> str:
    """Get address for coordinates using known mappings and cache."""

    # Check known locations first (exact match with threshold)
    for (known_lat, known_lon), address in KNOWN_LOCATIONS.items():
        distance = haversine_distance(lat, lon, known_lat, known_lon)
        if distance <= threshold_m:
            return address

    # Try geocode cache
    try:
        cache_file = Path(r"G:\My Drive\PROJECTS\APPS\GPS_Agent\geocode_cache.csv")
        if cache_file.exists():
            import csv
            with open(cache_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    try:
                        cache_lat = float(row['latitude'])
                        cache_lon = float(row['longitude'])
                        distance = haversine_distance(lat, lon, cache_lat, cache_lon)
                        if distance <= threshold_m and row.get('address'):
                            return row['address']
                    except:
                        continue
    except:
        pass

    # Return coordinates if no address found
    return f"({lat:.6f}, {lon:.6f})"

def extract_segments_with_metadata(segments: List[Dict], target_date: str) -> List[Dict]:
    """Extract Google Timeline segments with visit/activity metadata."""
    extracted_segments = []

    for segment in segments:
        # Parse segment times
        start_time = parse_timestamp(segment.get('startTime'))
        end_time = parse_timestamp(segment.get('endTime'))

        if not start_time:
            continue

        start_local = start_time.astimezone(timezone(timedelta(hours=-4)))

        # Check if segment is for target date
        if start_local.strftime('%Y-%m-%d') != target_date:
            continue

        # Determine segment type and extract location
        segment_type = None
        location = None

        if 'visit' in segment:
            segment_type = 'visit'
            # Try to get location from visit data
            visit = segment['visit']
            if 'topCandidate' in visit:
                candidate = visit['topCandidate']
                if 'placeLocation' in candidate:
                    loc = candidate['placeLocation']
                    if 'latLng' in loc:
                        lat_lng = loc['latLng']
                        if isinstance(lat_lng, str):
                            coords = parse_coordinates(lat_lng)
                            if coords:
                                location = {'lat': coords[0], 'lon': coords[1]}
        elif 'activity' in segment:
            segment_type = 'activity'
            activity = segment['activity']
            # Extract activity/travel mode
            activity_type = activity.get('topCandidateType', 'UNKNOWN')
            # For activities, we'll use start/end points or GPS breadcrumb centroid
            # Store for later use
            segment_metadata = {'activity_type': activity_type}
            # Activities don't have a single "location", they're movements

        # Extract GPS breadcrumbs from this segment
        gps_points = []
        if 'timelinePath' in segment:
            for point in segment['timelinePath']:
                point_time = parse_timestamp(point.get('time'))
                if not point_time:
                    continue

                point_local = point_time.astimezone(timezone(timedelta(hours=-4)))

                coords = None
                if 'point' in point:
                    if isinstance(point['point'], str):
                        coords = parse_coordinates(point['point'])
                    elif isinstance(point['point'], dict) and 'latitudeE7' in point['point']:
                        lat = point['point']['latitudeE7'] / 1e7
                        lon = point['point']['longitudeE7'] / 1e7
                        coords = (lat, lon)

                if coords:
                    gps_points.append({
                        'time': point_local,
                        'lat': coords[0],
                        'lon': coords[1]
                    })

        # If we have GPS points but no location from visit metadata, use GPS centroid
        if gps_points and not location:
            avg_lat = sum(p['lat'] for p in gps_points) / len(gps_points)
            avg_lon = sum(p['lon'] for p in gps_points) / len(gps_points)
            location = {'lat': avg_lat, 'lon': avg_lon}

        # For activities, include even without location (travel events)
        if segment_type == 'activity':
            # Include activity even if no specific location
            if not location and gps_points:
                # Use first/last points for travel
                location = {'lat': gps_points[0]['lat'], 'lon': gps_points[0]['lon']}

        if segment_type and (location or segment_type == 'activity'):
            seg_data = {
                'type': segment_type,
                'start_time': start_local,
                'end_time': end_local if (end_local := (end_time.astimezone(timezone(timedelta(hours=-4))) if end_time else start_local)) else start_local,
                'location': location,
                'gps_points': gps_points,
                'source': 'GOOGLE'
            }
            # Add activity type if this is an activity segment
            if segment_type == 'activity':
                # Get the activity_type from this segment's activity data
                activity_type = segment.get('activity', {}).get('topCandidateType', 'UNKNOWN')
                seg_data['activity_type'] = activity_type
            extracted_segments.append(seg_data)

    return extracted_segments

def extract_all_gps_breadcrumbs(segments: List[Dict], target_date: str, source_name: str) -> List[Dict]:
    """Extract ALL GPS points from timelinePath data - the real breadcrumbs."""
    all_points = []

    for segment in segments:
        if 'timelinePath' in segment:
            for point in segment['timelinePath']:
                point_time = parse_timestamp(point.get('time'))
                if not point_time:
                    continue

                point_local = point_time.astimezone(timezone(timedelta(hours=-4)))
                if point_local.strftime('%Y-%m-%d') != target_date:
                    continue

                coords = None
                data_source = source_name

                # Handle different coordinate formats
                if 'point' in point:
                    if isinstance(point['point'], str):
                        coords = parse_coordinates(point['point'])
                    elif isinstance(point['point'], dict) and 'latitudeE7' in point['point']:
                        lat = point['point']['latitudeE7'] / 1e7
                        lon = point['point']['longitudeE7'] / 1e7
                        coords = (lat, lon)

                # Check for Snapchat coordinates
                if 'coordinates_original' in point:
                    coord_orig = point['coordinates_original']
                    if 'lat' in coord_orig and 'lon' in coord_orig:
                        coords = (coord_orig['lat'], coord_orig['lon'])
                        data_source = f"{source_name}_SNAPCHAT"

                if coords:
                    # Get proper address
                    address = point.get('address', '')
                    if not address or address == '':
                        address = get_address_for_coordinates(coords[0], coords[1])

                    all_points.append({
                        'time': point_local,
                        'lat': coords[0],
                        'lon': coords[1],
                        'address': address,
                        'source': data_source
                    })

    return sorted(all_points, key=lambda x: x['time'])

def load_snapchat_data(target_date: str) -> List[Dict]:
    """Load Snapchat data for the specified date and convert to GPS points."""
    # Parse target date to get month
    target_dt = datetime.strptime(target_date, '%Y-%m-%d')
    month_num = target_dt.month
    month_names = {
        7: 'july', 8: 'august', 9: 'september', 10: 'october'
    }

    if month_num not in month_names:
        print(f"Warning: No Snapchat data file for month {month_num}")
        return []

    month_name = month_names[month_num]
    snapchat_file = Path(rf"G:\My Drive\PROJECTS\INVESTIGATION\Countdown\monthly_snapchat_timeline\snapchat_timeline_2025_{month_num:02d}_{month_name}.json")

    if not snapchat_file.exists():
        print(f"Warning: Snapchat file not found: {snapchat_file}")
        return []

    with open(snapchat_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    points = []
    for entry in data:
        if isinstance(entry, list) and len(entry) >= 2:
            timestamp_str, coords_str = entry

            try:
                # Parse timestamp
                timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S UTC")
                timestamp = timestamp.replace(tzinfo=timezone.utc)
                timestamp_local = timestamp.astimezone(timezone(timedelta(hours=-4)))

                if timestamp_local.strftime('%Y-%m-%d') != target_date:
                    continue

                # Parse coordinates
                lat_str, lon_str = coords_str.split(', ')
                latitude = float(lat_str)
                longitude = float(lon_str)

                points.append({
                    'time': timestamp_local,
                    'lat': latitude,
                    'lon': longitude,
                    'address': get_address_for_coordinates(latitude, longitude),
                    'source': 'SNAPCHAT'
                })
            except Exception as e:
                continue

    return points

def build_hourly_coverage_map(all_gps_points: List[Dict]) -> Dict[int, List[Dict]]:
    """Build map of hours to GPS points for coverage analysis."""
    hourly_map = defaultdict(list)

    for point in all_gps_points:
        hour = point['time'].hour
        hourly_map[hour].append(point)

    return hourly_map

def calculate_coverage_statistics(hourly_map: Dict[int, List[Dict]]) -> Dict[str, Any]:
    """Calculate coverage statistics for the day."""
    hours_with_data = len([h for h in hourly_map if hourly_map[h]])
    total_points = sum(len(points) for points in hourly_map.values())

    # Calculate unique minutes with data
    unique_minutes = set()
    for hour, points in hourly_map.items():
        for point in points:
            minute_key = (point['time'].hour, point['time'].minute)
            unique_minutes.add(minute_key)

    coverage_pct = (len(unique_minutes) / (24 * 60)) * 100

    # Find gaps (hours with no data)
    gaps = []
    for hour in range(24):
        if hour not in hourly_map or not hourly_map[hour]:
            gaps.append(hour)

    return {
        'hours_with_data': hours_with_data,
        'hours_without_data': 24 - hours_with_data,
        'total_gps_points': total_points,
        'unique_minutes_covered': len(unique_minutes),
        'coverage_percentage': coverage_pct,
        'gap_hours': gaps
    }

def generate_unified_timeline(target_date: str = "2025-08-14"):
    """Generate complete 24-hour timeline with Google + Snapchat data."""

    print(f"AUGUST 14, 2025 - UNIFIED 24-HOUR TIMELINE")
    print(f"Combining Google Timeline GPS + Snapchat Location Data")
    print("=" * 70)
    print()

    # Load Google GPS data
    google_data_file = Path(r"G:\My Drive\PROJECTS\APPS\GPS_Agent\GPS_By_Year\JSON_RAW\GPS Visits 2025.json")
    google_gps_data = load_gps_data(str(google_data_file))
    google_segments = filter_segments_from_date(google_gps_data['semanticSegments'], target_date)

    # Extract segments with metadata (visit/activity info)
    google_segments_with_metadata = extract_segments_with_metadata(google_segments, target_date)

    # Extract GPS breadcrumbs from Google Timeline
    google_gps_points = extract_all_gps_breadcrumbs(google_segments, target_date, 'GOOGLE')

    # Load Snapchat GPS data
    snapchat_gps_points = load_snapchat_data(target_date)

    print(f"Data loaded:")
    print(f"  Google GPS breadcrumbs: {len(google_gps_points)}")
    print(f"  Snapchat locations: {len(snapchat_gps_points)}")
    print()

    # Combine all GPS points
    all_gps_points = sorted(google_gps_points + snapchat_gps_points, key=lambda x: x['time'])

    print(f"Total unified GPS points: {len(all_gps_points)}")
    print()

    # Build hourly coverage map
    hourly_map = build_hourly_coverage_map(all_gps_points)

    # Calculate coverage statistics
    stats = calculate_coverage_statistics(hourly_map)

    print("=" * 70)
    print("COVERAGE ANALYSIS")
    print("=" * 70)
    print()
    print(f"Hours with GPS data: {stats['hours_with_data']}/24 ({stats['hours_with_data']/24*100:.1f}%)")
    print(f"Hours without data: {stats['hours_without_data']}/24")
    print(f"Total GPS points: {stats['total_gps_points']}")
    print(f"Unique minutes covered: {stats['unique_minutes_covered']}/1440 ({stats['coverage_percentage']:.1f}%)")
    print()

    if stats['gap_hours']:
        print(f"Gap hours (no GPS data): {', '.join(f'{h:02d}:00' for h in stats['gap_hours'])}")
    else:
        print("[OK] Complete 24-hour coverage achieved!")
    print()

    # Count sources
    google_count = len([p for p in all_gps_points if 'GOOGLE' in p['source']])
    snapchat_count = len([p for p in all_gps_points if 'SNAPCHAT' in p['source']])

    print(f"Data sources:")
    print(f"  Google Timeline: {google_count} points ({google_count/len(all_gps_points)*100:.1f}%)")
    print(f"  Snapchat: {snapchat_count} points ({snapchat_count/len(all_gps_points)*100:.1f}%)")
    print()

    # Generate hourly timeline
    print("=" * 70)
    print("24-HOUR TIMELINE")
    print("=" * 70)
    print()

    for hour in range(24):
        print(f"{hour:02d}:00 - {hour+1:02d}:00 EDT")
        print("-" * 40)

        if hour in hourly_map and hourly_map[hour]:
            points = hourly_map[hour]

            # Show coverage info
            sources = set(p['source'] for p in points)
            print(f"GPS Points: {len(points)} ({', '.join(sources)})")

            # Show time range
            first_point = points[0]
            last_point = points[-1]
            print(f"Coverage: {first_point['time'].strftime('%H:%M:%S')} - {last_point['time'].strftime('%H:%M:%S')}")

            # Show primary location (most common address) with precise coordinates
            from collections import Counter

            # Calculate centroid for coordinates
            avg_lat = sum(p['lat'] for p in points) / len(points)
            avg_lon = sum(p['lon'] for p in points) / len(points)

            # Get address (from points or lookup)
            addresses = [p['address'] for p in points if p['address']]
            if addresses:
                most_common_address = Counter(addresses).most_common(1)[0][0]
                print(f"Primary location: {most_common_address}")
            else:
                address = get_address_for_coordinates(avg_lat, avg_lon)
                if address:
                    print(f"Primary location: {address}")
                else:
                    print(f"Primary location: Unknown")

            # Always show precise coordinates
            print(f"Coordinates: ({avg_lat:.7f}, {avg_lon:.7f})")

        else:
            print("[X] NO GPS DATA - Gap period")

        print()

    # Save detailed report
    output_dir = Path(__file__).parent / "reports"
    output_dir.mkdir(exist_ok=True)

    report = {
        'date': target_date,
        'coverage_statistics': stats,
        'gps_points_by_hour': {
            hour: len(points) for hour, points in hourly_map.items()
        },
        'google_segments': [
            {
                'type': seg['type'],
                'start_time': seg['start_time'].isoformat(),
                'end_time': seg['end_time'].isoformat(),
                'location': seg['location'],
                'gps_points': [
                    {
                        'time': p['time'].isoformat(),
                        'lat': p['lat'],
                        'lon': p['lon']
                    }
                    for p in seg['gps_points']
                ],
                'source': seg['source'],
                **({'activity_type': seg['activity_type']} if 'activity_type' in seg else {})
            }
            for seg in google_segments_with_metadata
        ],
        'all_gps_points': [
            {
                'time': p['time'].isoformat(),
                'lat': p['lat'],
                'lon': p['lon'],
                'source': p['source'],
                'address': p['address']
            }
            for p in all_gps_points
        ]
    }

    # Generate output filename based on target_date
    target_dt = datetime.strptime(target_date, '%Y-%m-%d')
    month_name = target_dt.strftime('%B').lower()
    day = target_dt.day
    report_file = output_dir / f"{month_name}_{day}_2025_unified_timeline_complete.json"

    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2)

    print("=" * 70)
    print(f"Detailed report saved to: {report_file}")
    print("=" * 70)

    return report

if __name__ == "__main__":
    generate_unified_timeline()
