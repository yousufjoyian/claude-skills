"""
GPS Timeline Analyzer - User Input Validation Module
Version: 2.3
Purpose: Implement Section 0 (User Input Acquisition Protocol)
"""

import os
import json
import glob
from datetime import datetime, date
from pathlib import Path
from typing import Dict, List, Tuple, Optional


class InputValidator:
    """Validates and acquires user inputs for GPS timeline analysis"""

    def __init__(self):
        self.auto_discover_paths = {
            'google_timeline': [
                'GPS_By_Year/JSON_RAW/*.json',
                './GPS Visits *.json',
                '../GPS_By_Year/JSON_RAW/*.json'
            ],
            'snapchat': [
                'snapchat/location_history.json',
                './location_history.json',
                '../snapchat/location_history.json'
            ],
            'placebook': [
                'placebook.json',
                './placebook.json',
                'assets/placebook.json'
            ],
            'late_night_exceptions': [
                'late_night_exceptions.json',
                './late_night_exceptions.json',
                'assets/late_night_exceptions.json'
            ]
        }

    def validate_google_timeline_file(self, file_path: str) -> Tuple[bool, str]:
        """
        Validate Google Timeline JSON structure.

        Returns:
            (success: bool, message: str)
        """
        if not os.path.exists(file_path):
            return False, f"File not found: {file_path}"

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Check for semantic segments
            if 'semanticSegments' not in data:
                return False, "File doesn't contain 'semanticSegments' - may not be Google Timeline export"

            # Report findings
            num_segments = len(data['semanticSegments'])

            # Try to detect date range
            date_range = self._extract_date_range_from_segments(data['semanticSegments'])

            if date_range:
                start_date, end_date = date_range
                message = (
                    f"✅ Valid Google Timeline file with {num_segments} segments\n"
                    f"   Date range: {start_date} to {end_date}"
                )
            else:
                message = f"✅ Valid Google Timeline file with {num_segments} segments"

            return True, message

        except json.JSONDecodeError as e:
            return False, f"JSON parsing error: {e}"
        except Exception as e:
            return False, f"Error reading file: {e}"

    def validate_snapchat_file(self, file_path: str) -> Tuple[bool, str]:
        """
        Validate Snapchat location history structure.

        Returns:
            (success: bool, message: str)
        """
        if not os.path.exists(file_path):
            return False, f"File not found: {file_path}"

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Snapchat format: list of location records
            if not isinstance(data, list):
                return False, "Snapchat file should contain a list of location records"

            num_records = len(data)
            return True, f"✅ Valid Snapchat data with {num_records} location records"

        except json.JSONDecodeError as e:
            return False, f"JSON parsing error: {e}"
        except Exception as e:
            return False, f"Error reading file: {e}"

    def validate_date_range(self, start_date_str: str, end_date_str: Optional[str],
                           available_data_range: Tuple[date, date]) -> Tuple[bool, str]:
        """
        Validate requested date range against available data.

        Args:
            start_date_str: Start date in YYYY-MM-DD format
            end_date_str: End date in YYYY-MM-DD format (None for single day)
            available_data_range: (start_date, end_date) of available data

        Returns:
            (success: bool, message: str)
        """
        try:
            start = datetime.fromisoformat(start_date_str).date()
            end = datetime.fromisoformat(end_date_str).date() if end_date_str else start
        except ValueError as e:
            return False, f"Invalid date format: {e}. Use YYYY-MM-DD"

        # Check against available data
        data_start, data_end = available_data_range

        if start < data_start or end > data_end:
            return False, (
                f"Requested range ({start} to {end}) is outside "
                f"available data ({data_start} to {data_end})"
            )

        num_days = (end - start).days + 1
        return True, f"✅ Valid range: {num_days} day(s) from {start} to {end}"

    def validate_output_directory(self, output_dir: str) -> Tuple[bool, str]:
        """
        Ensure output directory exists or can be created.

        Returns:
            (success: bool, message: str)
        """
        output_path = Path(output_dir)

        try:
            output_path.mkdir(parents=True, exist_ok=True)
            return True, f"✅ Output directory ready: {output_path.absolute()}"
        except Exception as e:
            return False, f"Cannot create output directory: {e}"

    def auto_discover_google_timeline(self) -> Optional[List[str]]:
        """
        Auto-discover Google Timeline JSON files in common locations.

        Returns:
            List of file paths found, or None if not found
        """
        for pattern in self.auto_discover_paths['google_timeline']:
            matches = glob.glob(pattern)
            if matches:
                return sorted(matches)
        return None

    def auto_discover_snapchat(self) -> Optional[str]:
        """
        Auto-discover Snapchat location history in common locations.

        Returns:
            File path if found, or None
        """
        for path in self.auto_discover_paths['snapchat']:
            if os.path.exists(path):
                return path
        return None

    def auto_discover_placebook(self) -> Optional[str]:
        """Auto-discover place book configuration"""
        for path in self.auto_discover_paths['placebook']:
            if os.path.exists(path):
                return path
        return None

    def auto_discover_late_night_exceptions(self) -> Optional[str]:
        """Auto-discover late-night exceptions configuration"""
        for path in self.auto_discover_paths['late_night_exceptions']:
            if os.path.exists(path):
                return path
        return None

    def _extract_date_range_from_segments(self, segments: List[Dict]) -> Optional[Tuple[date, date]]:
        """Extract min/max dates from segments"""
        try:
            timestamps = []
            for segment in segments:
                if 'startTime' in segment:
                    ts_str = segment['startTime']
                    ts = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
                    timestamps.append(ts)

            if timestamps:
                min_date = min(timestamps).date()
                max_date = max(timestamps).date()
                return (min_date, max_date)
        except Exception:
            pass

        return None


def get_inputs_with_defaults(explicit_inputs: Optional[Dict] = None) -> Dict:
    """
    Get inputs with auto-discovery and defaults (silent mode support).

    Args:
        explicit_inputs: Dict of user-provided inputs

    Returns:
        Complete inputs dict with defaults filled in
    """
    validator = InputValidator()

    inputs = {
        'google_timeline': None,
        'snapchat': None,
        'date_range': None,
        'output_dir': './reports/',
        'place_book': None,
        'late_night_exceptions': None,
        'params': None  # Will use PARAMS_V2_3 from params module
    }

    # Try auto-discovery for Google Timeline
    if not explicit_inputs or not explicit_inputs.get('google_timeline'):
        auto_paths = validator.auto_discover_google_timeline()
        if auto_paths:
            inputs['google_timeline'] = auto_paths

    # Try auto-discovery for Snapchat
    if not explicit_inputs or not explicit_inputs.get('snapchat'):
        auto_path = validator.auto_discover_snapchat()
        if auto_path:
            inputs['snapchat'] = auto_path

    # Try auto-discovery for place book
    if not explicit_inputs or not explicit_inputs.get('place_book'):
        auto_path = validator.auto_discover_placebook()
        if auto_path:
            inputs['place_book'] = auto_path

    # Try auto-discovery for late-night exceptions
    if not explicit_inputs or not explicit_inputs.get('late_night_exceptions'):
        auto_path = validator.auto_discover_late_night_exceptions()
        if auto_path:
            inputs['late_night_exceptions'] = auto_path

    # If no date range specified, use all available data
    if not explicit_inputs or not explicit_inputs.get('date_range'):
        inputs['date_range'] = 'all'

    # Merge explicit inputs
    if explicit_inputs:
        inputs.update({k: v for k, v in explicit_inputs.items() if v is not None})

    return inputs


# User-facing prompt templates

PROMPT_GOOGLE_TIMELINE = """
📍 **Google Timeline JSON Required**

Please provide ONE of the following:
1. **Direct file path**: e.g., `G:\\My Drive\\PROJECTS\\APPS\\GPS_Agent\\GPS_By_Year\\JSON_RAW\\GPS Visits 2025.json`
2. **Directory to search**: I'll find all `GPS Visits *.json` files in that directory
3. **Navigate me**: Tell me the folder path and I'll list what's inside

💡 Tip: Google Timeline exports are usually named like "GPS Visits 2025.json"
"""

PROMPT_DATE_RANGE = """
📅 **Date Range Selection**

What time period should I analyze?

1. **Single day** - e.g., `2025-08-14`
2. **Date range** - e.g., `2025-07-24 to 2025-09-30`
3. **All available** - Process entire dataset
4. **Recent** - Last 7 days, last 30 days, etc.

💡 Tip: Single day analysis provides most detail. Large ranges produce summaries.
"""

PROMPT_SNAPCHAT = """
📸 **Snapchat Location History** (Optional)

Do you have Snapchat location data to include?
- ✅ **Yes** - Provide file path (e.g., `snapchat/location_history.json`)
- ⏭️ **No** - Skip (Google Timeline only)
- ❓ **Not sure** - I'll check if you have it in common locations

💡 Snapchat data improves coverage when Google Timeline has gaps
"""

PROMPT_OUTPUT_DIR = """
💾 **Output Location**

Where should I save the timeline reports?

1. **Default** - `./reports/` (recommended)
2. **Custom path** - Specify your preferred directory
3. **Same as input** - Save next to source JSON files

Press Enter for default, or specify custom path:
"""


def format_configuration_summary(inputs: Dict, validation_results: Dict) -> str:
    """
    Format configuration summary for user confirmation.

    Args:
        inputs: Dict of all inputs
        validation_results: Dict of validation results

    Returns:
        Formatted summary string
    """
    summary = """
📋 **Analysis Configuration Summary**

**Data Sources:**
"""

    # Google Timeline
    if inputs.get('google_timeline'):
        if isinstance(inputs['google_timeline'], list):
            summary += f"✅ Google Timeline: {len(inputs['google_timeline'])} files\n"
            for f in inputs['google_timeline']:
                summary += f"   - {Path(f).name}\n"
        else:
            summary += f"✅ Google Timeline: {Path(inputs['google_timeline']).name}\n"

        if 'google_timeline' in validation_results:
            summary += f"   {validation_results['google_timeline']}\n"
    else:
        summary += "❌ Google Timeline: NOT PROVIDED\n"

    # Snapchat
    if inputs.get('snapchat'):
        summary += f"✅ Snapchat: {Path(inputs['snapchat']).name}\n"
        if 'snapchat' in validation_results:
            summary += f"   {validation_results['snapchat']}\n"
    else:
        summary += "⏭️ Snapchat: Not included\n"

    # Date Range
    summary += f"\n**Date Range:**\n"
    if inputs.get('date_range'):
        if inputs['date_range'] == 'all':
            summary += "📅 All available data\n"
        else:
            summary += f"📅 {inputs['date_range']}\n"
    else:
        summary += "❌ Date range: NOT SPECIFIED\n"

    # Output
    summary += f"\n**Output:**\n"
    summary += f"💾 Directory: {inputs.get('output_dir', './reports/')}\n"
    summary += f"📄 Format: Detailed timeline with v2.3 header\n"

    # Optional
    summary += f"\n**Optional:**\n"
    summary += f"🏠 Place book: {'Using custom' if inputs.get('place_book') else 'Default (no custom names)'}\n"
    summary += f"🌙 Late-night exceptions: {'Configured' if inputs.get('late_night_exceptions') else 'None'}\n"
    summary += f"⚙️ Parameters: Default (movement=150m, gap=70min, visit_merge=300m/1min)\n"

    summary += "\n" + "━" * 70 + "\n"
    summary += "\nReady to proceed? (Yes/No)\n"

    return summary
