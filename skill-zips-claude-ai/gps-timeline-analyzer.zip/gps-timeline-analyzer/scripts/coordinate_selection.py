"""
GPS Timeline Analyzer - Coordinate Selection Module
Version: 2.3 (V8.2 Logic)
Purpose: Implement source prioritization and cached coordinate detection
"""

from typing import List, Dict, Tuple, Optional
from collections import defaultdict, Counter


def get_best_coordinate_v8_2(points: List[Dict]) -> Tuple[float, float, str, int]:
    """
    V8.2: Select best coordinate using source prioritization (NEVER average across sources).

    Priority:
    1. Google GPS/Wi-Fi breadcrumbs (7-decimal precision)
    2. Google Visit anchors (7-decimal precision, business address)
    3. Snapchat hourly data (3-4 decimal precision)
    4. Cell-only (low confidence)

    Args:
        points: List of GPS points with 'lat', 'lon', 'source', 'accuracy'

    Returns:
        (lat, lon, source_used, num_cached_filtered)
    """
    # Separate by source FIRST
    google_points = [p for p in points if p['source'].startswith('GOOGLE')]
    snapchat_points = [p for p in points if p['source'] == 'SNAPCHAT']

    num_cached = 0

    # Try Google first (PRIMARY)
    if google_points:
        # Detect cached coords in Google data
        cached_coords = detect_cached_coordinates_v2_2(google_points)
        good_google = [p for p in google_points
                      if not cached_coords.get((p['lat'], p['lon']), False)]

        num_cached = len(google_points) - len(good_google)

        if good_google:
            # Use last good Google point
            best = good_google[-1]
            return (best['lat'], best['lon'], best['source'], num_cached)
        else:
            # All Google points cached - use last one anyway (mark as cached)
            best = google_points[-1]
            return (best['lat'], best['lon'], f"{best['source']} (cached)", num_cached)

    # Fall back to Snapchat (SECONDARY)
    elif snapchat_points:
        # Same filtering logic for Snapchat
        cached_coords = detect_cached_coordinates_v2_2(snapchat_points)
        good_snap = [p for p in snapchat_points
                    if not cached_coords.get((p['lat'], p['lon']), False)]

        num_cached = len(snapchat_points) - len(good_snap)

        if good_snap:
            best = good_snap[-1]
            return (best['lat'], best['lon'], 'SNAPCHAT', num_cached)
        else:
            # All Snapchat cached - use last one
            best = snapchat_points[-1]
            return (best['lat'], best['lon'], 'SNAPCHAT (cached)', num_cached)

    # No points available
    return (None, None, 'NO_DATA', 0)


def detect_cached_coordinates_v2_2(points: List[Dict]) -> Dict[Tuple[float, float], bool]:
    """
    v2.2: Enhanced cached coordinate detection.

    Criteria:
    - Same lat/lon appears >5 times
    - Within 60-minute window
    - Flat accuracy (unchanged) or all inferred
    - Same source (or detect GPS↔Wi-Fi bouncing)

    Args:
        points: List of GPS points

    Returns:
        Dict mapping (lat, lon) -> is_cached (bool)
    """
    coord_groups = defaultdict(list)

    for point in points:
        coord = (point['lat'], point['lon'])
        coord_groups[coord].append(point)

    cached = {}

    for coord, coord_points in coord_groups.items():
        # Need >5 repetitions
        if len(coord_points) <= 5:
            cached[coord] = False
            continue

        # Sort by time
        coord_points.sort(key=lambda p: p['time'])

        # Check time window (must be within 60 minutes)
        time_span_min = (coord_points[-1]['time'] - coord_points[0]['time']).total_seconds() / 60
        if time_span_min > 60:
            cached[coord] = False
            continue

        # Check accuracy pattern
        accuracies = [p.get('accuracy') for p in coord_points if p.get('accuracy')]
        accuracy_types = [p.get('accuracy_type', 'measured') for p in coord_points]

        # If accuracy flat or all inferred, likely cached
        accuracy_flat = len(set(accuracies)) <= 2 if accuracies else True
        all_inferred = all(t == 'inferred' for t in accuracy_types)

        # Check source pattern
        sources = [p.get('source') for p in coord_points]
        source_bouncing = len(set(sources)) > 2  # GPS/Wi-Fi/CELL bouncing

        if source_bouncing:
            # Not cached, just switching sources at same location (e.g., building)
            cached[coord] = False
        elif accuracy_flat or all_inferred:
            # Likely cached
            cached[coord] = True
        else:
            cached[coord] = False

    return cached


def detect_snap_quantization(snap_points: List[Dict]) -> List[Dict]:
    """
    v2.2: Detect when Snapchat is using quantized/coarse coordinates.

    Pattern: Same 3-4 decimal coordinate repeated hour-over-hour.

    Args:
        snap_points: List of Snapchat GPS points

    Returns:
        Same list with 'is_quantized' and 'quantized_note' fields added
    """
    # Count coordinate frequencies
    coord_counts = Counter((p['lat'], p['lon']) for p in snap_points)

    # Check if dominated by low-precision repeats
    quantized_coords = {}

    for coord, count in coord_counts.items():
        lat, lon = coord

        # Check if low precision (3-4 decimals)
        lat_str = str(lat)
        lon_str = str(lon)

        lat_precision = len(lat_str.split('.')[-1]) if '.' in lat_str else 0
        lon_precision = len(lon_str.split('.')[-1]) if '.' in lon_str else 0

        if (lat_precision <= 4 and lon_precision <= 4 and count >= 3):
            quantized_coords[coord] = {
                'count': count,
                'precision': max(lat_precision, lon_precision)
            }

    # Mark affected points
    for point in snap_points:
        coord = (point['lat'], point['lon'])
        if coord in quantized_coords:
            point['is_quantized'] = True
            point['quantized_note'] = (
                f"Coarse/quantized: {quantized_coords[coord]['count']} identical "
                f"{quantized_coords[coord]['precision']}-decimal repeats"
            )
        else:
            point['is_quantized'] = False

    return snap_points


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate great-circle distance in meters using Haversine formula.

    Args:
        lat1, lon1: First coordinate (degrees)
        lat2, lon2: Second coordinate (degrees)

    Returns:
        Distance in meters
    """
    from math import radians, sin, cos, sqrt, atan2

    R = 6371000  # Earth radius in meters

    lat1_rad, lon1_rad, lat2_rad, lon2_rad = map(radians, [lat1, lon1, lat2, lon2])

    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad

    a = sin(dlat/2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))

    return R * c


def format_distance(distance_m: float) -> str:
    """
    v2.2: Format distance with both meters and km for quick scanning.

    Args:
        distance_m: Distance in meters

    Returns:
        Formatted string (e.g., "425m" or "1842m (1.84km)")
    """
    if distance_m < 1000:
        return f"{distance_m:.0f}m"
    else:
        return f"{distance_m:.0f}m ({distance_m/1000:.2f}km)"


def compute_speed(point1: Dict, point2: Dict) -> float:
    """
    Compute speed in km/h between consecutive GPS points.

    Args:
        point1: First GPS point with 'lat', 'lon', 'time'
        point2: Second GPS point with 'lat', 'lon', 'time'

    Returns:
        Speed in km/h
    """
    distance_m = haversine_distance(
        point1['lat'], point1['lon'],
        point2['lat'], point2['lon']
    )

    time_diff_hours = (point2['time'] - point1['time']).total_seconds() / 3600

    if time_diff_hours == 0:
        return float('inf')

    return distance_m / 1000 / time_diff_hours


def infer_activity_type_with_hysteresis(gps_points: List[Dict], hysteresis_intervals: int = 2) -> str:
    """
    v2.2: Infer activity type with hysteresis to prevent mode flip-flop.

    Requires ≥2 consecutive intervals above/below threshold before switching modes.

    Args:
        gps_points: List of GPS points
        hysteresis_intervals: Number of consecutive intervals required (default: 2)

    Returns:
        Activity type: 'IN_PASSENGER_VEHICLE', 'WALKING', 'MOVEMENT_UNKNOWN', 'UNKNOWN'
    """
    if len(gps_points) < 3:
        return 'UNKNOWN'

    speeds = []
    for i in range(len(gps_points) - 1):
        speed = compute_speed(gps_points[i], gps_points[i+1])
        speeds.append(speed)

    # Count consecutive intervals above/below thresholds
    vehicle_threshold = 8  # km/h
    walk_min = 1  # km/h
    walk_max = 7  # km/h

    # Check for consecutive vehicle-speed intervals
    consecutive_vehicle = 0
    max_consecutive_vehicle = 0

    for speed in speeds:
        if speed >= vehicle_threshold:
            consecutive_vehicle += 1
            max_consecutive_vehicle = max(max_consecutive_vehicle, consecutive_vehicle)
        else:
            consecutive_vehicle = 0

    # Check for consecutive walking-speed intervals
    consecutive_walk = 0
    max_consecutive_walk = 0

    for speed in speeds:
        if walk_min <= speed < walk_max:
            consecutive_walk += 1
            max_consecutive_walk = max(max_consecutive_walk, consecutive_walk)
        else:
            consecutive_walk = 0

    # Apply hysteresis: need N consecutive intervals
    if max_consecutive_vehicle >= hysteresis_intervals:
        return 'IN_PASSENGER_VEHICLE'
    elif max_consecutive_walk >= hysteresis_intervals:
        return 'WALKING'
    else:
        return 'MOVEMENT_UNKNOWN'


def override_with_google_label(inferred_type: str, google_label: Optional[str],
                               confidence: float) -> Tuple[str, str]:
    """
    v2.2: Allow Google label override for inner-city congestion.

    Keep IN_VEHICLE even if speed <8 km/h if Google explicitly labels it
    and confidence >0.7.

    Args:
        inferred_type: Type inferred from speed analysis
        google_label: Google's activity label (if available)
        confidence: Google's confidence score (0-1)

    Returns:
        (final_type, reason)
    """
    if google_label == 'IN_PASSENGER_VEHICLE' and confidence > 0.7:
        return google_label, f'Google label (high confidence: {confidence:.2f})'
    else:
        return inferred_type, 'Speed inference'


# Source label normalization

SOURCE_ALIASES = {
    'GPS': ['GPS', 'GNSS', 'FUSED', 'gps'],
    'WIFI': ['WIFI', 'WIFI_SCAN', 'WiFi', 'wifi'],
    'CELL': ['CELL', 'CELL_TOWER', 'cellular', 'cell'],
    'UNKNOWN': ['UNKNOWN', 'unknown', None]
}


def normalize_source_label(raw_source: Optional[str]) -> str:
    """
    Normalize source labels across different export formats.

    Args:
        raw_source: Raw source string from GPS data

    Returns:
        Normalized source label ('GPS', 'WIFI', 'CELL', 'UNKNOWN')
    """
    if not raw_source:
        return 'UNKNOWN'

    raw_upper = str(raw_source).upper()

    for canonical, aliases in SOURCE_ALIASES.items():
        if raw_upper in [a.upper() for a in aliases if a]:
            return canonical

    return 'UNKNOWN'


def get_or_infer_accuracy(point: Dict) -> Tuple[float, str]:
    """
    Get accuracy or infer from source when missing.

    Args:
        point: GPS point dict

    Returns:
        (accuracy: float, accuracy_type: str) where type is 'measured' or 'inferred'
    """
    if 'accuracy' in point and point['accuracy'] is not None:
        return point['accuracy'], 'measured'

    # Infer from source
    source = point.get('source', 'UNKNOWN')

    inferred_accuracy = {
        'GPS': 10,      # ±10m typical GPS
        'WIFI': 30,     # ±30m typical Wi-Fi
        'CELL': 500,    # ±500m typical cell
        'UNKNOWN': 999  # Unknown
    }.get(source, 999)

    return inferred_accuracy, 'inferred'
