#!/usr/bin/env python3
"""
Generate detailed August 14, 2025 timeline with V8.2 logic:
- V8.1: Google primary, visit segments, no cross-source averaging
- V8.2 FIX: Cluster points with same timestamp together regardless of distance
"""
import sys
from pathlib import Path
from datetime import datetime, timedelta, timezone
import math
from collections import Counter
from typing import List, Dict

sys.path.insert(0, str(Path(__file__).parent))
from comprehensive_analysis import load_gps_data, filter_segments_from_date
from generate_august_14_unified_timeline import (
    load_snapchat_data,
    get_address_for_coordinates,
    haversine_distance,
    parse_timestamp,
    parse_coordinates,
    extract_all_gps_breadcrumbs
)

# Import V8 functions
from generate_august_14_detailed_timeline_v8 import (
    detect_cached_coordinates,
    classify_stay_confidence,
    get_best_coordinate_v8,
    format_time,
    format_duration
)

def extract_visit_gps_points(segments: List[Dict], target_date: str, source_name: str) -> List[Dict]:
    """Extract GPS coordinates from Google Timeline VISIT segments."""
    visit_points = []

    for segment in segments:
        if 'visit' not in segment:
            continue

        start_time = parse_timestamp(segment.get('startTime'))
        end_time = parse_timestamp(segment.get('endTime'))

        if not start_time:
            continue

        start_local = start_time.astimezone(timezone(timedelta(hours=-4)))

        if start_local.strftime('%Y-%m-%d') != target_date:
            continue

        visit = segment['visit']
        if 'topCandidate' in visit:
            candidate = visit['topCandidate']
            if 'placeLocation' in candidate:
                loc = candidate['placeLocation']
                if 'latLng' in loc:
                    coords = parse_coordinates(loc['latLng'])
                    if coords:
                        lat, lon = coords

                        visit_points.append({
                            'time': start_local,
                            'lat': lat,
                            'lon': lon,
                            'source': source_name
                        })

                        if end_time:
                            end_local = end_time.astimezone(timezone(timedelta(hours=-4)))
                            if (end_local - start_local).total_seconds() > 60:
                                visit_points.append({
                                    'time': end_local,
                                    'lat': lat,
                                    'lon': lon,
                                    'source': source_name
                                })

    return visit_points

def cluster_into_stays_v8_2(gps_points, min_stay_duration_min=0, movement_threshold_m=150, max_gap_min=70):
    """
    Cluster GPS points with V8.2 logic:
    - Google primary, no cross-source averaging
    - FIX: Points with same timestamp always clustered together (visit + breadcrumb at same time)
    """
    if not gps_points:
        return []

    stays = []
    current_stay = {
        'start_time': gps_points[0]['time'],
        'end_time': gps_points[0]['time'],
        'points': [gps_points[0]]
    }

    for point in gps_points[1:]:
        time_gap_min = (point['time'] - current_stay['end_time']).total_seconds() / 60

        # Calculate distance from ANY point in current stay
        min_distance = float('inf')
        for existing_point in current_stay['points']:
            distance = haversine_distance(
                existing_point['lat'], existing_point['lon'],
                point['lat'], point['lon']
            )
            min_distance = min(min_distance, distance)

        # V8.2 FIX: If time_gap < 1 minute AND involves a VISIT point, cluster together
        # This handles visit segments that are close in time to breadcrumbs but different coords
        # (visit = business address, breadcrumb = parking location nearby)
        # BUT: They must be within 300m to prevent clustering different locations
        has_visit_point = (point['source'].endswith('_VISIT') or
                          any(p['source'].endswith('_VISIT') for p in current_stay['points']))

        if time_gap_min < 1 and has_visit_point and min_distance <= 300:
            # Very close in time and space with visit involvement - cluster together
            current_stay['end_time'] = point['time']
            current_stay['points'].append(point)
        elif time_gap_min <= max_gap_min and min_distance <= movement_threshold_m:
            # Normal clustering logic
            current_stay['end_time'] = point['time']
            current_stay['points'].append(point)
        else:
            # Save current stay
            if len(current_stay['points']) >= 1:
                lat, lon, coord_source, num_cached = get_best_coordinate_v8(current_stay['points'])

                current_stay['lat'] = lat
                current_stay['lon'] = lon
                current_stay['coord_source'] = coord_source
                current_stay['num_cached'] = num_cached
                current_stay['address'] = get_address_for_coordinates(lat, lon)
                current_stay['sources'] = list(set(p['source'] for p in current_stay['points']))
                current_stay['confidence'] = classify_stay_confidence(current_stay)

                stays.append(current_stay)

            # Start new stay
            current_stay = {
                'start_time': point['time'],
                'end_time': point['time'],
                'points': [point]
            }

    # Don't forget last stay
    if current_stay['points']:
        lat, lon, coord_source, num_cached = get_best_coordinate_v8(current_stay['points'])

        current_stay['lat'] = lat
        current_stay['lon'] = lon
        current_stay['coord_source'] = coord_source
        current_stay['num_cached'] = num_cached
        current_stay['address'] = get_address_for_coordinates(lat, lon)
        current_stay['sources'] = list(set(p['source'] for p in current_stay['points']))
        current_stay['confidence'] = classify_stay_confidence(current_stay)

        stays.append(current_stay)

    return stays

def main():
    target_date = '2025-08-14'

    print(f"Loading data for {target_date}...")

    # Load Google GPS data
    google_data_file = Path(r"G:\My Drive\PROJECTS\APPS\GPS_Agent\GPS_By_Year\JSON_RAW\GPS Visits 2025.json")
    google_gps_data = load_gps_data(str(google_data_file))
    target_segments = filter_segments_from_date(google_gps_data['semanticSegments'], target_date)

    # Extract GPS breadcrumbs + visit points
    google_breadcrumbs = extract_all_gps_breadcrumbs(target_segments, target_date, 'GOOGLE')
    google_visits = extract_visit_gps_points(target_segments, target_date, 'GOOGLE_VISIT')
    google_points = google_breadcrumbs + google_visits

    # Load Snapchat data
    snapchat_points = load_snapchat_data(target_date)

    # Merge all GPS points
    all_gps_points = google_points + snapchat_points
    all_gps_points.sort(key=lambda p: p['time'])

    print(f"Total GPS points: {len(all_gps_points)}")
    print(f"  Google (breadcrumbs + visits): {len(google_points)}")
    print(f"  Snapchat: {len(snapchat_points)}")
    print()

    # Cluster into stays with V8.2 logic
    stays = cluster_into_stays_v8_2(all_gps_points, min_stay_duration_min=0, movement_threshold_m=150, max_gap_min=70)

    print(f"Identified {len(stays)} stay periods")
    print()

    # Generate output
    print("=" * 70)
    print(f"{target_date.upper()} - DETAILED TIMELINE V8.2")
    print("Google PRIMARY (breadcrumbs + visits), Snapchat FALLBACK")
    print("FIX: Same-timestamp points clustered together")
    print("=" * 70)
    print()

    # Track coverage
    day_start = datetime(2025, 8, 14, 0, 0, 0, tzinfo=all_gps_points[0]['time'].tzinfo)
    day_end = datetime(2025, 8, 15, 0, 0, 0, tzinfo=day_start.tzinfo)

    current_time = day_start

    # Count by confidence
    confirmed = [s for s in stays if s['confidence'] == 'CONFIRMED']
    ambiguous = [s for s in stays if s['confidence'] == 'AMBIGUOUS']
    cached = [s for s in stays if s['confidence'] == 'CACHED']

    for stay in stays:
        # Check for gap before this stay
        if stay['start_time'] > current_time:
            gap_min = (stay['start_time'] - current_time).total_seconds() / 60
            if gap_min >= 1:
                print(f"[GAP] {format_time(current_time)} - {format_time(stay['start_time'])}")
                print(f"      No GPS data ({int(gap_min)} minutes)")
                print()

        # Show the stay with confidence marker
        duration = format_duration(stay['start_time'], stay['end_time'])

        confidence_marker = {
            'CONFIRMED': '',
            'AMBIGUOUS': ' [?]',
            'CACHED': ' [CACHED DATA]'
        }[stay['confidence']]

        print(f"{format_time(stay['start_time'])} - {format_time(stay['end_time'])} ({duration}){confidence_marker}")
        print(f"  Location: {stay['address']}")
        print(f"  Coordinates: ({stay['lat']:.7f}, {stay['lon']:.7f}) [from {stay['coord_source']}]")

        # Show confidence explanation
        if stay['confidence'] == 'AMBIGUOUS':
            print(f"  Confidence: AMBIGUOUS (single point or brief duration)")
        elif stay['confidence'] == 'CACHED':
            print(f"  Confidence: CACHED ({stay['num_cached']} cached coordinates in {stay['coord_source']})")
        elif stay['num_cached'] > 0:
            print(f"  Filtered: Excluded {stay['num_cached']} cached {stay['coord_source']} coordinates")

        print(f"  GPS points: {len(stay['points'])} ({', '.join(stay['sources'])})")
        print()

        current_time = stay['end_time']

    # Check for gap at end
    if current_time < day_end:
        gap_min = (day_end - current_time).total_seconds() / 60
        if gap_min >= 1:
            print(f"[GAP] {format_time(current_time)} - 12:00 AM (next day)")
            print(f"      No GPS data ({int(gap_min)} minutes)")
            print()

    # Summary
    total_covered = sum((s['end_time'] - s['start_time']).total_seconds() for s in stays) / 60
    coverage_pct = (total_covered / (24 * 60)) * 100
    total_cached = sum(s['num_cached'] for s in stays)

    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"Total stays: {len(stays)}")
    print(f"  CONFIRMED stays: {len(confirmed)}")
    print(f"  AMBIGUOUS stays: {len(ambiguous)}")
    print(f"  CACHED-data stays: {len(cached)}")
    print()
    print(f"Total GPS points: {len(all_gps_points)}")
    print(f"Cached coordinates filtered: {total_cached}")
    print(f"Coverage: {coverage_pct:.1f}% ({int(total_covered)} minutes)")
    print()

if __name__ == '__main__':
    main()
