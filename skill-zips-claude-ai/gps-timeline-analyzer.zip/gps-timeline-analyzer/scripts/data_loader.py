#!/usr/bin/env python3
"""
Comprehensive GPS Timeline Analysis from July 24, 2025 onwards
Creates a single consolidated report for all dates.
"""

import json
import sys
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Tuple
from pathlib import Path
import zoneinfo

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

def load_gps_data(file_path: str) -> Dict[str, Any]:
    """Load GPS data from the JSON file."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def filter_segments_from_date(segments: List[Dict], start_date: str) -> List[Dict]:
    """Filter segments from the specified start date onwards."""
    target_date = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
    filtered = []

    for segment in segments:
        start_time = datetime.fromisoformat(segment['startTime'].replace('Z', '+00:00'))
        if start_time.date() >= target_date.date():
            filtered.append(segment)

    return filtered

def group_segments_by_date(segments: List[Dict]) -> Dict[str, List[Dict]]:
    """Group segments by date."""
    grouped = {}

    for segment in segments:
        start_time = datetime.fromisoformat(segment['startTime'].replace('Z', '+00:00'))
        date_key = start_time.date().isoformat()

        if date_key not in grouped:
            grouped[date_key] = []
        grouped[date_key].append(segment)

    return grouped

def find_precise_coordinates(segments: List[Dict], target_time: str) -> Dict[str, str]:
    """Find precise GPS coordinates and address from timelinePath at a specific time.

    Returns dict with 'point', 'address', 'time_diff', and 'gps_time' keys, or None if not found.
    """
    from datetime import datetime
    target_dt = datetime.fromisoformat(target_time.replace('Z', '+00:00'))

    # Find the closest GPS point in time
    closest_point = None
    closest_diff = float('inf')
    closest_time = None

    for segment in segments:
        if 'timelinePath' in segment:
            for point in segment['timelinePath']:
                point_time = point.get('time', '')
                if point_time:
                    point_dt = datetime.fromisoformat(point_time.replace('Z', '+00:00'))
                    time_diff = abs((point_dt - target_dt).total_seconds())
                    # Expand window to 5 minutes and keep track of closest
                    if time_diff <= 300 and time_diff < closest_diff:
                        closest_diff = time_diff
                        closest_time = point_time
                        closest_point = {
                            'point': point['point'],
                            'address': point.get('address', 'Address not available'),
                            'time_diff_seconds': time_diff,
                            'gps_time': point_time
                        }

    return closest_point

def detect_gps_clusters(gps_points: List[Tuple[str, str, str]], threshold_meters: float = 100) -> List[List[Tuple[str, str, str]]]:
    """Group GPS points into clusters based on proximity.

    Args:
        gps_points: List of (time, coordinates, address) tuples
        threshold_meters: Distance threshold for clustering

    Returns:
        List of clusters, each containing GPS points
    """
    from location_mapping import haversine_distance, parse_coordinates

    if not gps_points:
        return []

    clusters = []
    current_cluster = [gps_points[0]]

    for i in range(1, len(gps_points)):
        prev_lat, prev_lon = parse_coordinates(gps_points[i-1][1])
        curr_lat, curr_lon = parse_coordinates(gps_points[i][1])

        distance = haversine_distance(prev_lat, prev_lon, curr_lat, curr_lon)

        if distance <= threshold_meters:
            current_cluster.append(gps_points[i])
        else:
            clusters.append(current_cluster)
            current_cluster = [gps_points[i]]

    if current_cluster:
        clusters.append(current_cluster)

    return clusters

def split_misclassified_activity(segment: Dict, all_segments: List[Dict]) -> List[Dict]:
    """Split misclassified activity into stays and movements based on GPS clustering.

    Detects when Google misclassifies a long-duration, short-distance activity
    and splits it into actual stays and movements.

    Args:
        segment: Activity segment to analyze
        all_segments: All segments for GPS point lookup

    Returns:
        List of corrected segments (stays and movements)
    """
    from datetime import datetime

    start_dt = datetime.fromisoformat(segment['startTime'].replace('Z', '+00:00'))
    end_dt = datetime.fromisoformat(segment['endTime'].replace('Z', '+00:00'))
    duration_minutes = (end_dt - start_dt).total_seconds() / 60
    distance = segment['activity']['distanceMeters']

    # Detect misclassification: long duration (>60 min) + short distance (<500m)
    if duration_minutes > 60 and distance < 500:
        # Get GPS points from timelinePath
        gps_points = []
        for seg in all_segments:
            if 'timelinePath' in seg:
                for point in seg['timelinePath']:
                    point_time = point.get('time', '')
                    if point_time:
                        point_dt = datetime.fromisoformat(point_time.replace('Z', '+00:00'))
                        if start_dt <= point_dt <= end_dt:
                            gps_points.append((
                                point_time,
                                point['point'],
                                point.get('address', 'Address not available')
                            ))

        if len(gps_points) >= 3:
            # Cluster GPS points
            clusters = detect_gps_clusters(gps_points, threshold_meters=100)

            # Build segments from clusters
            # Only keep substantial stays (>5 min or >3 GPS points)
            substantial_stays = []
            for i, cluster in enumerate(clusters):
                cluster_start_time = cluster[0][0]
                cluster_end_time = cluster[-1][0]
                cluster_coords = cluster[-1][1]
                cluster_address = cluster[-1][2]

                cluster_start_dt = datetime.fromisoformat(cluster_start_time.replace('Z', '+00:00'))
                cluster_end_dt = datetime.fromisoformat(cluster_end_time.replace('Z', '+00:00'))
                cluster_duration = (cluster_end_dt - cluster_start_dt).total_seconds() / 60

                # Only keep clusters with significant duration (>5 min) or multiple GPS samples (>3 points)
                if cluster_duration >= 5 or len(cluster) > 3:
                    substantial_stays.append({
                        'startTime': cluster_start_time,
                        'endTime': cluster_end_time,
                        'location': cluster_coords,
                        'address': cluster_address,
                        'duration': cluster_duration
                    })

            # Build result segments with stays and movements between substantial stays only
            result_segments = []
            for i, stay in enumerate(substantial_stays):
                # Add the stay
                result_segments.append({
                    'type': 'stay',
                    'startTime': stay['startTime'],
                    'endTime': stay['endTime'],
                    'location': stay['location'],
                    'address': stay['address'],
                    'source': 'gps_clustering'
                })

                # Add movement to next substantial stay
                if i < len(substantial_stays) - 1:
                    next_stay = substantial_stays[i + 1]

                    result_segments.append({
                        'type': 'movement',
                        'startTime': stay['endTime'],
                        'endTime': next_stay['startTime'],
                        'startLocation': stay['location'],
                        'endLocation': next_stay['location'],
                        'startAddress': stay['address'],
                        'endAddress': next_stay['address'],
                        'source': 'gps_clustering'
                    })

            return result_segments if result_segments else None

    return None

def merge_overlapping_visits(visits: List[Dict]) -> List[Dict]:
    """Merge overlapping visit segments, keeping the most precise one.

    When hierarchyLevel 0 and 1 overlap, keep level 1 if it has a timelinePath address
    (more precise), otherwise keep level 0 (primary classification).

    Args:
        visits: List of visit segments with hierarchyLevel

    Returns:
        Deduplicated list of visits
    """
    from datetime import datetime

    if not visits:
        return []

    # Sort by start time
    sorted_visits = sorted(visits, key=lambda v: v['startTime'])

    merged = []
    skip_indices = set()

    for i, visit in enumerate(sorted_visits):
        if i in skip_indices:
            continue

        start_dt = datetime.fromisoformat(visit['startTime'].replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(visit['endTime'].replace('Z', '+00:00'))

        # Check for overlapping visits
        overlapping = [visit]
        for j in range(i + 1, len(sorted_visits)):
            if j in skip_indices:
                continue

            other_visit = sorted_visits[j]
            other_start = datetime.fromisoformat(other_visit['startTime'].replace('Z', '+00:00'))
            other_end = datetime.fromisoformat(other_visit['endTime'].replace('Z', '+00:00'))

            # Check if they overlap (more than 50% overlap)
            overlap_start = max(start_dt, other_start)
            overlap_end = min(end_dt, other_end)

            if overlap_start < overlap_end:
                overlap_duration = (overlap_end - overlap_start).total_seconds()
                visit_duration = (end_dt - start_dt).total_seconds()
                overlap_ratio = overlap_duration / visit_duration if visit_duration > 0 else 0

                if overlap_ratio > 0.5:
                    overlapping.append(other_visit)
                    skip_indices.add(j)

        # Choose the best visit from overlapping ones
        if len(overlapping) > 1:
            # Prefer visits with timelinePath addresses (more precise)
            with_address = [v for v in overlapping if v['placeVisit'].get('address')]
            if with_address:
                # Among those with addresses, prefer hierarchyLevel 1 (more specific)
                level_1 = [v for v in with_address if v.get('hierarchyLevel', 0) == 1]
                best_visit = level_1[0] if level_1 else with_address[0]
            else:
                # No addresses, prefer hierarchyLevel 0 (primary classification)
                level_0 = [v for v in overlapping if v.get('hierarchyLevel', 0) == 0]
                best_visit = level_0[0] if level_0 else overlapping[0]

            # Remove hierarchyLevel from final output
            if 'hierarchyLevel' in best_visit:
                del best_visit['hierarchyLevel']
            merged.append(best_visit)
        else:
            # No overlap, just add it
            if 'hierarchyLevel' in visit:
                del visit['hierarchyLevel']
            merged.append(visit)

    return merged

def analyze_day(date_str: str, segments: List[Dict]) -> Dict[str, Any]:
    """Analyze a single day's GPS data."""

    # Import location mapping
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent))
    from location_mapping import enhance_location_with_mapping

    # Parse the segments into activities, visits, and timeline paths
    activities = []
    visits = []
    timeline_paths = []

    for segment in segments:
        if 'activity' in segment:
            # Check if this activity is misclassified (long duration, short distance)
            split_segments = split_misclassified_activity(segment, segments)

            if split_segments:
                # Activity was misclassified - add the split segments directly
                for split_seg in split_segments:
                    if split_seg['type'] == 'stay':
                        # Add as a visit
                        semantic_type = 'UNKNOWN'
                        enhanced_type, known_location = enhance_location_with_mapping(split_seg['location'], semantic_type)

                        visit_data = {
                            'startTime': split_seg['startTime'],
                            'endTime': split_seg['endTime'],
                            'placeVisit': {
                                'location': {'latLng': split_seg['location']},
                                'placeConfidence': 0.9,  # High confidence from GPS clustering
                                'semanticType': enhanced_type,
                                'knownLocation': known_location,
                                'address': split_seg['address']
                            }
                        }
                        visits.append(visit_data)
                    elif split_seg['type'] == 'movement':
                        # Add as an activity
                        from location_mapping import haversine_distance, parse_coordinates
                        start_lat, start_lon = parse_coordinates(split_seg['startLocation'])
                        end_lat, end_lon = parse_coordinates(split_seg['endLocation'])
                        distance = haversine_distance(start_lat, start_lon, end_lat, end_lon)

                        activity_data = {
                            'startTime': split_seg['startTime'],
                            'endTime': split_seg['endTime'],
                            'activitySegment': {
                                'startLocation': {'latLng': split_seg['startLocation']},
                                'endLocation': {'latLng': split_seg['endLocation']},
                                'startAddress': split_seg['startAddress'],
                                'endAddress': split_seg['endAddress'],
                                'distance': distance,
                                'activityType': 'IN_PASSENGER_VEHICLE'
                            }
                        }
                        activities.append(activity_data)
            else:
                # Normal activity processing
                start_location = segment['activity']['start']
                end_location = segment['activity']['end']
                start_address = None
                end_address = None

                # Try to get precise end coordinates from timelinePath
                precise_end = find_precise_coordinates(segments, segment['endTime'])
                end_gps_note = None
                if precise_end:
                    end_location = {'latLng': precise_end['point']}
                    end_address = precise_end['address']
                    if precise_end['time_diff_seconds'] > 60:
                        end_gps_note = f"GPS sampled {int(precise_end['time_diff_seconds'])}s from activity end"

                # Try to get precise start coordinates from timelinePath
                precise_start = find_precise_coordinates(segments, segment['startTime'])
                start_gps_note = None
                if precise_start:
                    start_location = {'latLng': precise_start['point']}
                    start_address = precise_start['address']
                    if precise_start['time_diff_seconds'] > 60:
                        start_gps_note = f"GPS sampled {int(precise_start['time_diff_seconds'])}s from activity start"

                distance = segment['activity']['distanceMeters']

                activity_data = {
                    'startTime': segment['startTime'],
                    'endTime': segment['endTime'],
                    'activitySegment': {
                        'startLocation': start_location,
                        'endLocation': end_location,
                        'startAddress': start_address,
                        'endAddress': end_address,
                        'distance': distance,
                        'activityType': segment['activity']['topCandidate']['type']
                    }
                }
                activities.append(activity_data)
        elif 'visit' in segment:
            # Transform visit segment to expected format
            # Process ALL hierarchy levels, we'll intelligently merge later
            hierarchy_level = segment['visit'].get('hierarchyLevel', 0)
            location = segment['visit']['topCandidate']['placeLocation']['latLng']
            semantic_type = segment['visit']['topCandidate'].get('semanticType', 'UNKNOWN')

            # Try to get precise coordinates from timelinePath
            # Only override if GPS point is VERY close in time (<60 sec)
            from location_mapping import parse_coordinates, haversine_distance
            visit_address = None
            precise_start = find_precise_coordinates(segments, segment['startTime'])

            # Also check if there are GPS points at this visit location
            # to adjust the actual arrival time
            visit_lat, visit_lon = parse_coordinates(location)
            actual_arrival_time = None

            for seg in segments:
                if 'timelinePath' in seg:
                    for point in seg['timelinePath']:
                        if 'time' in point and 'point' in point:
                            point_lat, point_lon = parse_coordinates(point['point'])
                            dist = haversine_distance(visit_lat, visit_lon, point_lat, point_lon)
                            # If GPS point is within 200m of visit location
                            if dist <= 200:
                                point_dt = datetime.fromisoformat(point['time'].replace('Z', '+00:00'))
                                visit_start_dt = datetime.fromisoformat(segment['startTime'].replace('Z', '+00:00'))
                                # Use earliest GPS point at this location after stated start time
                                if point_dt >= visit_start_dt:
                                    if actual_arrival_time is None or point_dt < datetime.fromisoformat(actual_arrival_time.replace('Z', '+00:00')):
                                        actual_arrival_time = point['time']
                                        if not visit_address:
                                            visit_address = point.get('address', 'Address not available')

            # Only override location if GPS point matches the stated start time very closely
            # AND we didn't already find a different arrival time based on GPS at the visit location
            if precise_start and precise_start['time_diff_seconds'] < 60 and not actual_arrival_time:
                location = precise_start['point']
                visit_address = precise_start['address']

            # Enhance with known location mapping
            enhanced_type, known_location = enhance_location_with_mapping(location, semantic_type)

            # Use actual arrival time if found, otherwise use Google's time
            visit_start_time = actual_arrival_time if actual_arrival_time else segment['startTime']

            visit_data = {
                'startTime': visit_start_time,
                'endTime': segment['endTime'],
                'hierarchyLevel': hierarchy_level,
                'placeVisit': {
                    'location': {'latLng': location},
                    'placeConfidence': segment['visit']['probability'],
                    'semanticType': enhanced_type,
                    'knownLocation': known_location,
                    'address': visit_address
                }
            }
            visits.append(visit_data)
        elif 'timelinePath' in segment:
            # Timeline path segment - already in good format
            timeline_paths.append(segment)

    # Merge overlapping visits intelligently
    visits = merge_overlapping_visits(visits)

    # Detect missing trips from GPS breadcrumbs
    # Look for large gaps between consecutive GPS points indicating movement
    all_gps_points = []
    for seg in segments:
        if 'timelinePath' in seg:
            for point in seg['timelinePath']:
                if 'time' in point and 'point' in point:
                    all_gps_points.append({
                        'time': point['time'],
                        'coords': point['point'],
                        'address': point.get('address', 'Address not available')
                    })

    # Sort by time
    all_gps_points.sort(key=lambda x: x['time'])

    # Detect missing trips (consecutive points far apart in distance)
    from location_mapping import haversine_distance, parse_coordinates
    missing_trips = []

    for i in range(len(all_gps_points) - 1):
        curr = all_gps_points[i]
        next_point = all_gps_points[i + 1]

        curr_dt = datetime.fromisoformat(curr['time'].replace('Z', '+00:00'))
        next_dt = datetime.fromisoformat(next_point['time'].replace('Z', '+00:00'))
        time_gap_minutes = (next_dt - curr_dt).total_seconds() / 60

        # Calculate distance between points
        curr_lat, curr_lon = parse_coordinates(curr['coords'])
        next_lat, next_lon = parse_coordinates(next_point['coords'])
        distance = haversine_distance(curr_lat, curr_lon, next_lat, next_lon)

        # If points are >1km apart and time gap is 5-60 minutes, it's likely a missing trip
        if distance > 1000 and 5 <= time_gap_minutes <= 60:
            # Check if this trip is already covered by an activity
            trip_covered = False
            for activity in activities:
                act_start = datetime.fromisoformat(activity['startTime'].replace('Z', '+00:00'))
                act_end = datetime.fromisoformat(activity['endTime'].replace('Z', '+00:00'))
                # If activity overlaps with this time window, it's covered
                if act_start <= curr_dt <= act_end or act_start <= next_dt <= act_end:
                    trip_covered = True
                    break

            if not trip_covered:
                # Add as a missing trip
                missing_trips.append({
                    'startTime': curr['time'],
                    'endTime': next_point['time'],
                    'activitySegment': {
                        'startLocation': {'latLng': curr['coords']},
                        'endLocation': {'latLng': next_point['coords']},
                        'startAddress': curr['address'],
                        'endAddress': next_point['address'],
                        'distance': distance,
                        'activityType': 'IN_PASSENGER_VEHICLE'
                    }
                })

    # Add missing trips to activities
    activities.extend(missing_trips)

    # Use simple analysis without the complex stitcher for now
    # Just process the raw segments directly
    processed_segments = []

    # Process activities
    for activity in activities:
        activity_segment = activity['activitySegment']
        start_time = activity['startTime']
        end_time = activity['endTime']

        # Calculate duration
        start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
        duration_minutes = (end_dt - start_dt).total_seconds() / 60

        processed_segments.append({
            'type': 'activity',
            'start_time': start_time,
            'end_time': end_time,
            'duration_minutes': duration_minutes,
            'activity_type': activity_segment.get('activityType', 'UNKNOWN'),
            'distance_meters': activity_segment.get('distance', 0),
            'start_location': activity_segment.get('startLocation', {}),
            'end_location': activity_segment.get('endLocation', {}),
            'start_address': activity_segment.get('startAddress'),
            'end_address': activity_segment.get('endAddress'),
            'verdict': 'REAL'
        })

    # Process visits
    for visit in visits:
        visit_segment = visit['placeVisit']
        start_time = visit['startTime']
        end_time = visit['endTime']

        # Calculate duration
        start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
        duration_minutes = (end_dt - start_dt).total_seconds() / 60

        processed_segments.append({
            'type': 'visit',
            'start_time': start_time,
            'end_time': end_time,
            'duration_minutes': duration_minutes,
            'semantic_type': visit_segment.get('semanticType', 'UNKNOWN'),
            'known_location': visit_segment.get('knownLocation'),
            'location': visit_segment.get('location', {}),
            'visit_address': visit_segment.get('address'),
            'confidence': visit_segment.get('placeConfidence', 0),
            'verdict': 'REAL'
        })

    # Process timeline paths
    for path in timeline_paths:
        start_time = path['startTime']
        end_time = path['endTime']

        # Calculate duration
        start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
        duration_minutes = (end_dt - start_dt).total_seconds() / 60

        # Calculate path distance if points available
        distance_meters = 0
        gps_points = len(path.get('timelinePath', []))

        processed_segments.append({
            'type': 'path',
            'start_time': start_time,
            'end_time': end_time,
            'duration_minutes': duration_minutes,
            'distance_meters': distance_meters,
            'gps_points': gps_points,
            'verdict': 'PATH'
        })

    classified_timeline = processed_segments

    # Calculate coverage
    toronto_tz = zoneinfo.ZoneInfo("America/Toronto")
    day_start = datetime.fromisoformat(f"{date_str}T00:00:00").replace(tzinfo=toronto_tz)
    day_end = day_start + timedelta(days=1)

    covered_minutes = 0
    total_minutes = 24 * 60

    for segment in classified_timeline:
        seg_start = datetime.fromisoformat(segment['start_time'].replace('Z', '+00:00'))
        seg_end = datetime.fromisoformat(segment['end_time'].replace('Z', '+00:00'))

        # Convert to Toronto timezone
        seg_start = seg_start.astimezone(toronto_tz)
        seg_end = seg_end.astimezone(toronto_tz)

        # Check overlap with the day
        overlap_start = max(seg_start, day_start)
        overlap_end = min(seg_end, day_end)

        if overlap_start < overlap_end:
            overlap_minutes = (overlap_end - overlap_start).total_seconds() / 60
            covered_minutes += overlap_minutes

    coverage_percent = min(100.0, (covered_minutes / total_minutes) * 100)

    # Separate activities and visits
    day_activities = [s for s in classified_timeline if s.get('type') == 'activity']
    day_visits = [s for s in classified_timeline if s.get('type') == 'visit']
    day_paths = [s for s in classified_timeline if s.get('type') == 'path']

    return {
        'date': date_str,
        'coverage_percent': coverage_percent,
        'total_segments': len(classified_timeline),
        'activities': day_activities,
        'visits': day_visits,
        'paths': day_paths,
        'anomalies': [s for s in classified_timeline if s.get('verdict') in ['AMBIGUOUS', 'GPS_JUMP', 'UNRELIABLE']]
    }

def create_comprehensive_report(data_file: str, start_date: str = "2025-07-24") -> Dict[str, Any]:
    """Create comprehensive analysis report from the GPS data file."""

    print(f"Loading GPS data from {data_file}...")
    gps_data = load_gps_data(data_file)

    print(f"Total segments in file: {gps_data.get('total_segments', 'unknown')}")

    # Filter segments from start date onwards
    print(f"Filtering segments from {start_date} onwards...")
    filtered_segments = filter_segments_from_date(gps_data['semanticSegments'], start_date)
    print(f"Filtered segments: {len(filtered_segments)}")

    # Group by date
    print("Grouping segments by date...")
    daily_segments = group_segments_by_date(filtered_segments)
    print(f"Days with data: {len(daily_segments)}")

    # Analyze each day
    comprehensive_report = {
        'analysis_timestamp': datetime.now().isoformat(),
        'start_date': start_date,
        'total_days': len(daily_segments),
        'daily_analyses': {}
    }

    sorted_dates = sorted(daily_segments.keys())

    for date_str in sorted_dates:
        print(f"Analyzing {date_str}...")
        segments = daily_segments[date_str]

        try:
            day_analysis = analyze_day(date_str, segments)
            comprehensive_report['daily_analyses'][date_str] = day_analysis
            print(f"  SUCCESS {date_str}: {day_analysis['total_segments']} segments, {day_analysis['coverage_percent']:.1f}% coverage")
        except Exception as e:
            print(f"  ERROR {date_str}: Error - {str(e)}")
            comprehensive_report['daily_analyses'][date_str] = {
                'date': date_str,
                'error': str(e),
                'coverage_percent': 0,
                'total_segments': 0,
                'activities': [],
                'visits': [],
                'paths': [],
                'anomalies': []
            }

    return comprehensive_report

def main():
    """Main execution function."""
    data_file = r"G:\My Drive\PROJECTS\APPS\GPS_Agent\GPS_By_Year\JSON_W_ADDRESS\GPS Visits 2025 with Addresses.json"
    report_file = r"G:\My Drive\PROJECTS\APPS\GPS_Agent\comprehensive_gps_report.json"

    print("=== Comprehensive GPS Timeline Analysis ===")
    print("Starting from July 24, 2025 onwards")
    print()

    # Create comprehensive report
    report = create_comprehensive_report(data_file)

    # Save report to file
    print(f"\nSaving comprehensive report to {report_file}...")
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"SUCCESS: Comprehensive report saved!")
    print(f"SUCCESS: Total days analyzed: {report['total_days']}")
    print(f"SUCCESS: Date range: {min(report['daily_analyses'].keys())} to {max(report['daily_analyses'].keys())}")

    return report

if __name__ == "__main__":
    main()