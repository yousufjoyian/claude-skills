#!/usr/bin/env python3
"""
Generate detailed timelines for all dates using V8.2 (FIXED) logic.
Batch generation script for July 24 - September 30, 2025.
"""
import sys
from pathlib import Path
from datetime import datetime, timedelta, timezone

sys.path.insert(0, str(Path.cwd()))
from comprehensive_analysis import load_gps_data, filter_segments_from_date
from generate_august_14_unified_timeline import (
    load_snapchat_data,
    get_address_for_coordinates,
    haversine_distance,
    extract_all_gps_breadcrumbs
)
from generate_august_14_detailed_timeline_v8_2 import (
    extract_visit_gps_points,
    cluster_into_stays_v8_2,
    get_best_coordinate_v8,
    classify_stay_confidence,
    format_time,
    format_duration
)

def generate_timeline_v8_2(target_date: str, output_dir: Path):
    """Generate a single timeline for the given date."""

    # Load Google GPS data
    google_data_file = Path(r"G:\My Drive\PROJECTS\APPS\GPS_Agent\GPS_By_Year\JSON_RAW\GPS Visits 2025.json")
    google_gps_data = load_gps_data(str(google_data_file))
    target_segments = filter_segments_from_date(google_gps_data['semanticSegments'], target_date)

    # Extract GPS breadcrumbs + visit points
    google_breadcrumbs = extract_all_gps_breadcrumbs(target_segments, target_date, 'GOOGLE')
    google_visits = extract_visit_gps_points(target_segments, target_date, 'GOOGLE_VISIT')
    google_points = google_breadcrumbs + google_visits

    # Load Snapchat data
    snapchat_points = load_snapchat_data(target_date)

    # Merge all GPS points
    all_gps_points = google_points + snapchat_points

    if not all_gps_points:
        return None  # No data for this date

    all_gps_points.sort(key=lambda p: p['time'])

    # Cluster into stays with V8.2 logic
    stays = cluster_into_stays_v8_2(all_gps_points, min_stay_duration_min=0, movement_threshold_m=150, max_gap_min=70)

    # Generate output
    output_lines = []
    output_lines.append(f"Loading data for {target_date}...")
    output_lines.append(f"Total GPS points: {len(all_gps_points)}")
    output_lines.append(f"  Google (breadcrumbs + visits): {len(google_points)}")
    output_lines.append(f"  Snapchat: {len(snapchat_points)}")
    output_lines.append("")
    output_lines.append(f"Identified {len(stays)} stay periods")
    output_lines.append("")
    output_lines.append("=" * 70)
    output_lines.append(f"{target_date.upper()} - DETAILED TIMELINE V8.2")
    output_lines.append("Google PRIMARY (breadcrumbs + visits), Snapchat FALLBACK")
    output_lines.append("FIX: Visit points clustered with nearby breadcrumbs")
    output_lines.append("=" * 70)
    output_lines.append("")

    # Track coverage
    day_start = datetime.strptime(target_date, '%Y-%m-%d').replace(tzinfo=all_gps_points[0]['time'].tzinfo)
    day_end = day_start + timedelta(days=1)

    current_time = day_start

    # Count by confidence
    confirmed = [s for s in stays if s['confidence'] == 'CONFIRMED']
    ambiguous = [s for s in stays if s['confidence'] == 'AMBIGUOUS']
    cached = [s for s in stays if s['confidence'] == 'CACHED']

    for stay in stays:
        # Check for gap before this stay
        if stay['start_time'] > current_time:
            gap_min = (stay['start_time'] - current_time).total_seconds() / 60
            if gap_min >= 1:
                output_lines.append(f"[GAP] {format_time(current_time)} - {format_time(stay['start_time'])}")
                output_lines.append(f"      No GPS data ({int(gap_min)} minutes)")
                output_lines.append("")

        # Show the stay with confidence marker
        duration = format_duration(stay['start_time'], stay['end_time'])

        confidence_marker = {
            'CONFIRMED': '',
            'AMBIGUOUS': ' [?]',
            'CACHED': ' [CACHED DATA]'
        }[stay['confidence']]

        output_lines.append(f"{format_time(stay['start_time'])} - {format_time(stay['end_time'])} ({duration}){confidence_marker}")
        output_lines.append(f"  Location: {stay['address']}")
        output_lines.append(f"  Coordinates: ({stay['lat']:.7f}, {stay['lon']:.7f}) [from {stay['coord_source']}]")

        # Show confidence explanation
        if stay['confidence'] == 'AMBIGUOUS':
            output_lines.append(f"  Confidence: AMBIGUOUS (single point or brief duration)")
        elif stay['confidence'] == 'CACHED':
            output_lines.append(f"  Confidence: CACHED ({stay['num_cached']} cached coordinates in {stay['coord_source']})")
        elif stay['num_cached'] > 0:
            output_lines.append(f"  Filtered: Excluded {stay['num_cached']} cached {stay['coord_source']} coordinates")

        output_lines.append(f"  GPS points: {len(stay['points'])} ({', '.join(stay['sources'])})")
        output_lines.append("")

        current_time = stay['end_time']

    # Check for gap at end
    if current_time < day_end:
        gap_min = (day_end - current_time).total_seconds() / 60
        if gap_min >= 1:
            output_lines.append(f"[GAP] {format_time(current_time)} - 12:00 AM (next day)")
            output_lines.append(f"      No GPS data ({int(gap_min)} minutes)")
            output_lines.append("")

    # Summary
    total_covered = sum((s['end_time'] - s['start_time']).total_seconds() for s in stays) / 60
    coverage_pct = (total_covered / (24 * 60)) * 100
    total_cached = sum(s['num_cached'] for s in stays)

    output_lines.append("=" * 70)
    output_lines.append("SUMMARY")
    output_lines.append("=" * 70)
    output_lines.append(f"Total stays: {len(stays)}")
    output_lines.append(f"  CONFIRMED stays: {len(confirmed)}")
    output_lines.append(f"  AMBIGUOUS stays: {len(ambiguous)}")
    output_lines.append(f"  CACHED-data stays: {len(cached)}")
    output_lines.append("")
    output_lines.append(f"Total GPS points: {len(all_gps_points)}")
    output_lines.append(f"Cached coordinates filtered: {total_cached}")
    output_lines.append(f"Coverage: {coverage_pct:.1f}% ({int(total_covered)} minutes)")
    output_lines.append("")

    # Write to file
    output_file = output_dir / f"{target_date}_detailed_timeline_v8_2.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(output_lines))

    return output_file

def main():
    # Create output directory
    output_dir = Path("unified_timelines_v8_2_fixed")
    output_dir.mkdir(exist_ok=True)

    # Generate timelines for July 24 - September 30, 2025
    start_date = datetime(2025, 7, 24)
    end_date = datetime(2025, 9, 30)

    current_date = start_date
    generated = 0
    skipped = 0

    print("Starting batch timeline generation with V8.2 (FIXED)...")
    print(f"Date range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
    print("=" * 70)
    print()

    while current_date <= end_date:
        target_date = current_date.strftime('%Y-%m-%d')

        try:
            output_file = generate_timeline_v8_2(target_date, output_dir)

            if output_file:
                print(f"[OK] Generated: {output_file.name}")
                generated += 1
            else:
                print(f"[SKIP] Skipped: {target_date} (no GPS data)")
                skipped += 1

        except Exception as e:
            print(f"[ERROR] Error on {target_date}: {e}")
            skipped += 1

        current_date += timedelta(days=1)

    print()
    print("=" * 70)
    print(f"Batch generation complete!")
    print(f"  Generated: {generated} timelines")
    print(f"  Skipped: {skipped} dates")
    print(f"  Output directory: {output_dir}")
    print("=" * 70)

if __name__ == '__main__':
    main()
